# Bubble Blast Bangla

An offline-first Android bubble-shooter game. Kotlin + Jetpack Compose.

## Status: Phase 6.1 — release-candidate hardening pass (v0.6.1)

**This is a release-candidate polish pass, not a production-ready build.**
Every "works" claim below is based on source-code review (tracing the
actual logic, not trusting comments or prior README claims) — this project
has never been compiled or run. See "Build & runtime status" below before
you rely on anything here.

## Game overview

A casual, family-friendly bubble shooter (spec: ages ~5–20). Aim and shoot
colored bubbles, match 3+ of the same color to clear them, complete 100
levels of increasing difficulty, earn stars/coins, spend them in a Shop on
power-ups/themes/bubble skins, and come back daily for a 7-day reward cycle.
The whole game — gameplay, progression, shop, daily rewards, settings,
tutorial — works fully offline; nothing requires a network connection.

## Technology stack

- **Kotlin** + **Jetpack Compose** for all UI (Material 3 theming, no XML layouts)
- **Custom Canvas-based rendering** for the bubble board/shooter — no game
  engine (libGDX/Unity). A casual 2D grid-matcher doesn't need one; a
  lightweight custom engine keeps the codebase small, dependency-free, and
  easy for a beginner to read (see the Phase 1 architecture rationale
  preserved in code comments throughout `game/`).
- **Jetpack Navigation-Compose** for screen routing
- **DataStore Preferences** for all persistence (see "Save system" below)
- **Core library desugaring** enabled so `java.time` (used by the offline-safe
  daily-reward date logic) works down to `minSdk 24`

## Project structure

```
app/src/main/java/com/bubbleblastbangla/
├── app/            Application class, DI-lite container (AppContainer)
├── navigation/      Screen routes (Screen.kt) + NavGraph.kt wiring
├── game/            Pure-Kotlin game engine — zero Compose/Android dependency
│   ├── model/         BubbleColor
│   ├── board/          BubbleGrid, GridMath, CellCoord (offset-row grid geometry)
│   ├── matching/        MatchFinder (BFS clustering), FallDetector (ceiling reachability)
│   ├── shooter/          Shooter, TrajectoryCalculator (aim/bounce simulation)
│   ├── powerups/          PowerUpEffect (Bomb/Lightning/Rainbow/FireBall)
│   └── GameSession.kt      Orchestrates one level playthrough
├── data/
│   ├── models/         LevelConfig, PlayerProgress, PowerUpType, CosmeticItem, DailyRewardCatalog, TargetType
│   ├── level/           LevelRepository — generates all 100 LevelConfigs from a difficulty formula
│   ├── persistence/       SaveManager — the one class that talks to DataStore
│   └── repository/         ProgressRepository — in-memory StateFlow + write-through to SaveManager
├── ui/
│   ├── theme/          Colors, typography, Material3 theme
│   ├── components/      Shared widgets (RoundedGameButton, CoinCounter/HeartCounter, PandaMascot)
│   ├── home/, levelmap/, gameplay/, shop/, dailyreward/, settings/, tutorial/,
│   │   levelcomplete/, gameover/    One real screen per spec destination
│   └── gameplay/BubbleSkinRenderer.kt   Skin-aware bubble drawing (visual only)
└── state/            rememberProgressRepository() — Compose access to the app-wide singleton
```

Levels are never hardcoded into gameplay code: `LevelRepository` generates a
`LevelConfig` for any level number from a formula (colors/shots/target
tighten as the number rises), so adding Level 101+ needs no new code.

## Current completed features

- **Gameplay** — offset-grid bubble board, drag-to-aim with a live bouncing
  trajectory line, BFS same-color matching (3+), ceiling-reachability
  falling of disconnected bubbles, 4 working power-ups with real inventory
  (tap to select, tap the board to target).
- **Bubble skins** — Classic/Candy/Galaxy/Neon/Rainbow, purchasable and
  selectable in the Shop, and the selected skin now actually renders in
  gameplay (`BubbleSkinRenderer`) — visual only, the underlying match color
  is untouched.
- **Level progression** — 100 levels, Level 1 unlocked by default, clearing
  a level unlocks the next, completed levels are replayable, best score and
  best star rating are both kept permanently (never regress).
- **Coin economy** — centralized in `ProgressRepository`: earned on level
  clear and daily rewards, balance checked before every spend, never
  negative, saved immediately on every change.
- **Power-ups** — Bomb (destroys neighbors), Lightning (clears the row),
  Rainbow (clears every bubble of the tapped color), Fire Ball (clears the
  column). Earnable via a quick-buy-on-tap flow in Gameplay, or through the
  full Shop.
- **Shop** — 3 tabs (Power-ups / Bubble Skins / Themes), owned/selected
  states, insufficient-coin feedback, purchases persist.
- **Daily rewards** — real 7-day cycle, offline-safe (device-local epoch
  day, not elapsed time — see `ProgressRepository.claimDailyReward`), Day 7
  grants 500 coins **plus a real bonus Bomb power-up**, granted exactly once
  per claim.
- **Hearts** — max 5, lost on a failed level, and now **regenerate
  automatically** over real elapsed time (one heart per 5 minutes),
  computed from a saved timestamp so it works correctly whether the app was
  open, backgrounded, or fully closed — see `ProgressRepository.refreshHeartRegen`.
- **Settings** — Music/Sound/Vibration toggles (take effect immediately),
  a two-step Reset Progress confirmation dialog, a real Rate Game button
  (opens the Play Store, browser fallback, fails gracefully if neither is
  available), an honest Privacy Policy row (says "Not yet published" rather
  than linking to nothing — see `StoreLinks.kt`), and a non-fake Language
  row ("English only" — the persisted `language` field exists for a future
  picker, no fake switch was built).
- **Tutorial** — 8 pages (aim, match, fall, all 4 power-ups, win),
  Prev/Next/Skip, progress dots.
- **Level Complete / Game Over** — real score, best score, coins earned
  (Level Complete only), Next Level/Retry/Home. Rewards are granted exactly
  once (inside `GameplayViewModel`, before navigation) — these screens only
  display what already happened, never re-grant it.

## Offline functionality

Every feature above works with no network connection — there are no network
calls anywhere in the save, shop, or gameplay path. The only place a network
concept appears at all is the disabled "Continue (Watch Ad)" option on Game
Over, which is intentionally inert (no ad SDK is wired up until Phase 6) and
never blocks retrying.

## Save system

`SaveManager` (DataStore Preferences) is the single facade for persistence;
`ProgressRepository` holds the current `PlayerProgress` in a `StateFlow` and
writes through to `SaveManager` on every change, so memory and disk never
drift apart. This is a deliberate simplification from the original
DataStore+Room plan — see the rationale comment at the top of
`SaveManager.kt`. Every field added since has followed the same pattern:
new DataStore key, decoded with a safe default so existing saves never lose
data just because a new field was introduced.

## Level system

`LevelRepository.configFor(levelNumber)` generates a `LevelConfig`
(bubble layout, colors, shot limit, target, coin reward, star thresholds)
for any level 1-100+ from a difficulty formula — no per-level code, no
100 hardcoded screens.

## Coin system

See `ProgressRepository.spendCoins`/`addCoins` — the one place coin math
happens.

## Power-ups

See `game/powerups/PowerUpEffect.kt` for the gameplay effects and
`ProgressRepository` for inventory/purchase logic.

## Known limitations

- No sound/particles play yet — real audio/animation hooks exist
  (`GameplayAudioHooks`, no-op today) and fire at every real gameplay event,
  ready for a Phase 6 implementation to plug into with no call-site changes.
- No real ad network — Game Over's "Continue" option is honestly disabled.
- Only English is supported; the `language` field and non-fake Settings row
  exist for a future picker, no localized strings exist yet.
- Launcher icon is placeholder art with only an adaptive-icon (API 26+)
  resource — no fallback raster mipmap for API 24–25 yet.
- Heart regeneration is checked periodically while the app is open (a
  30-second poll on Home) rather than via a system alarm/notification —
  correct results either way since the calculation is timestamp-based, but
  the UI won't tick up a heart at the exact millisecond while the player is
  on a different screen; it catches up the next time regen is checked.

## Build & runtime status (v0.6.1)

**Version:** `versionName = "0.6.1"`, `versionCode = 7`, `applicationId = "com.bubbleblastbangla"`,
`compileSdk`/`targetSdk = 34`, `minSdk = 24` — all unchanged from earlier
phases; none of these needed adjusting.

**Build:** `./gradlew assembleDebug` was **not run and did not succeed**,
because this environment has no Gradle installation, no committed Gradle
wrapper JAR, and no network access to fetch either (confirmed by directly
testing network access before writing this section — it's blocked).
`gradle/wrapper/gradle-wrapper.properties` is included, specifying Gradle
8.7 (the minimum compatible with AGP 8.5.2), but the wrapper's executable
scripts (`gradlew`/`gradlew.bat`) and its JAR are **not** included — I chose
not to hand-write those from memory, since a subtly wrong wrapper script
would be worse than none. **To build:** open the project folder in Android
Studio (Hedgehog or newer) and let it regenerate the wrapper automatically,
or run `gradle wrapper` once with a local Gradle 8.7+ install, then
`./gradlew assembleDebug`.

**Runtime:** Not tested — no emulator or device is available in this
environment. No APK exists.

**What "reviewed" means here:** every behavioral claim in this README is
backed by reading the actual source (not comments, not prior README
claims) — tracing state-update logic by hand, cross-checking every
screen's function signature against its `NavGraph` call site, and
confirming save-data invariants (coins ≥ 0, hearts clamped to
`0..maxHearts`, power-up inventory checked-then-decremented atomically)
directly in `SaveManager`/`ProgressRepository`. This is thorough static
review, not compilation or execution.

## Phase 6: audio, haptics, animation, particles, ads architecture

- **Audio** (`audio/`) — `SoundManager` (SoundPool) and `MusicManager`
  (MediaPlayer, won't restart an already-playing track) behind one entry
  point, `GameAudioController`, which always respects the existing
  Music/Sound settings. **No audio files ship with this project** — every
  sound/music event is looked up by filename at runtime and silently
  skipped if missing, so the app builds and runs correctly with zero audio
  assets. See `res/raw/README.txt` for the exact filenames a real licensed
  audio pass should use.
- **Haptics** (`haptics/HapticManager.kt`) — real `Vibrator` feedback for
  button press, shot, match, power-up, level complete/over, purchase, daily
  reward, and insufficient coins; respects the Vibration setting; no-ops
  gracefully on vibrator-less devices.
- **Particles** (`ui/gameplay/ParticleSystem.kt`) — a small, bounded (max
  150), dependency-free particle system for bubble pop/fall/power-up
  feedback, plus a genuine shrink-and-fade animation on the popped bubble
  itself rather than an instant disappearance. Ticks only while particles
  are actually alive (idle-polls otherwise) so it doesn't burn a frame
  callback for the whole time the player is on the Gameplay screen.
- **Button polish** — `RoundedGameButton` now has a press-scale animation
  and a built-in tap-debounce (ignores a second tap within 400ms) so rapid
  double-tapping can't fire BUY/CLAIM/PLAY/etc twice; the hand-rolled
  power-up buttons in Gameplay got the same protection since they don't use
  `RoundedGameButton`. A `LocalGameFeedback` CompositionLocal gives every
  button a standard press sound+haptic without each call site wiring it up.
- **Panda mascot** — idle breathing animation plus three reaction moods
  (HAPPY on Level Complete, SAD on Game Over, EXCITED on Daily Reward), all
  procedural (no new art assets).
- **Ads architecture** (`ads/AdProvider.kt`) — a real, swappable interface
  (rewarded + interstitial) with `NoOpAdProvider` as the only shipped
  implementation. No SDK included, per the instructions; Game Over's
  Continue option stays honestly disabled until a real provider is wired in.
- **Accessibility** — coin/heart counters now expose a merged content
  description ("Coins: 250") instead of a screen reader reading a bare
  number with no context.

### Known Phase 6 limitations
- No audio actually plays yet (architecture is real and complete; assets are not — see above).
- Bubble skins still don't factor into the particle/pop colors (they use the base match color, which is correct/intentional — skins are a rendering-only concern).
- No exhaustive on-device responsive-UI testing was possible in this environment; layouts use `fillMaxWidth`/`aspectRatio`/`LazyColumn`/`LazyVerticalGrid` throughout, which are inherently adaptive, but this is a code-review conclusion, not a verified one across real screen sizes.
- Launcher icon still lacks a fallback raster mipmap for API 24–25.
## Phase 6.1 — release-candidate audit findings

A full source-level audit (not a rewrite) was performed across power-ups,
save data, daily reward, hearts, shop, navigation, and audio/particle
lifecycle. Result: **no regressions or new bugs found** — every invariant
checked (power-up inventory can't go negative or be double-consumed by
rapid taps, coins/hearts are clamped on every save, purchases charge and
grant atomically, no duplicate reward paths) was already correctly
implemented in earlier phases and remains correct now. This pass's actual
changes were: version metadata (`0.1.0-phase2` → `0.6.1`), the Gradle
wrapper properties file, and this documentation update — deliberately no
new features, per the phase's own instructions.

## Where to place final assets

- **Audio**: `app/src/main/res/raw/` — see `res/raw/README.txt` for the
  exact filenames each sound effect and music track expects. Drop in
  licensed `.mp3`/`.ogg`/`.wav` files with those names and playback starts
  automatically, no code changes needed.
- **Ads**: implement `com.bubbleblastbangla.ads.AdProvider` with a real SDK
  and swap it in at `BubbleBlastApplication.adProvider`'s single
  construction site.
- **Launcher icon**: `app/src/main/res/drawable/ic_launcher_foreground.xml`
  is placeholder art with no fallback raster mipmap for API 24–25 — replace
  before a real release.
