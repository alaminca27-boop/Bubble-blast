# Add project specific ProGuard rules here.
# Room, Compose, and kotlinx.serialization keep-rules will be added in Phase 6
# (performance/release-hardening pass), not needed for debug builds during development.
