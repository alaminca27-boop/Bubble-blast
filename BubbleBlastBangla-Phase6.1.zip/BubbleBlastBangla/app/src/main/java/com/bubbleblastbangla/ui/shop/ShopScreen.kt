package com.bubbleblastbangla.ui.shop

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.data.models.BubbleSkinCatalog
import com.bubbleblastbangla.data.models.CosmeticItem
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.data.models.ThemeCatalog
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.CoinCounter
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubbleGreen
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.LockedGray
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.SurfaceCardMuted
import com.bubbleblastbangla.ui.theme.TextPrimary

private enum class ShopTab { POWER_UPS, SKINS, THEMES }

/**
 * Shop screen (spec section 12). All three categories read/write through
 * the existing ProgressRepository — no separate shop state. Purchases are
 * synchronous StateFlow updates (see ProgressRepository), so a rapid
 * double-tap on Buy is naturally safe: the second tap re-checks the
 * just-updated in-memory balance/ownership before spending anything.
 */
@Composable
fun ShopScreen(onBack: () -> Unit) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    var tab by remember { mutableStateOf(ShopTab.POWER_UPS) }
    var feedback by remember { mutableStateOf<String?>(null) }

    feedback?.let { message ->
        LaunchedEffect(message) {
            kotlinx.coroutines.delay(1800)
            feedback = null
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(SurfaceCardMuted)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundedGameButton(text = "BACK", baseColor = BubblePurple, modifier = Modifier.width(100.dp), height = 48.dp, onClick = onBack)
            Text(text = "SHOP", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, fontWeight = FontWeight.ExtraBold)
            CoinCounter(coins = progress.coins)
        }

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            TabChip("Power-ups", tab == ShopTab.POWER_UPS) { tab = ShopTab.POWER_UPS }
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(4.dp))
            TabChip("Bubble Skins", tab == ShopTab.SKINS) { tab = ShopTab.SKINS }
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(4.dp))
            TabChip("Themes", tab == ShopTab.THEMES) { tab = ShopTab.THEMES }
        }

        feedback?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp).clip(RoundedCornerShape(10.dp)).background(BubblePurple).padding(8.dp)
            )
        }

        when (tab) {
            ShopTab.POWER_UPS -> PowerUpTab(
                inventory = progress.powerUpInventory,
                coins = progress.coins,
                onBuy = { type ->
                    val ok = progressRepository.purchasePowerUp(type)
                    feedback = if (ok) "${type.displayName} purchased!" else "Not enough coins for ${type.displayName}"
                }
            )
            ShopTab.SKINS -> CosmeticTab(
                items = BubbleSkinCatalog.all,
                owned = progress.ownedBubbleSkins,
                selected = progress.selectedBubbleSkin,
                coins = progress.coins,
                onBuy = { item ->
                    val ok = progressRepository.purchaseBubbleSkin(item.id, item.price)
                    feedback = if (ok) "${item.displayName} unlocked!" else "Not enough coins for ${item.displayName}"
                },
                onSelect = { item -> progressRepository.selectBubbleSkin(item.id) }
            )
            ShopTab.THEMES -> CosmeticTab(
                items = ThemeCatalog.all,
                owned = progress.ownedThemes,
                selected = progress.selectedTheme,
                coins = progress.coins,
                onBuy = { item ->
                    val ok = progressRepository.purchaseTheme(item.id, item.price)
                    feedback = if (ok) "${item.displayName} unlocked!" else "Not enough coins for ${item.displayName}"
                },
                onSelect = { item -> progressRepository.selectTheme(item.id) }
            )
        }
    }
}

@Composable
private fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) BubblePurple else SurfaceCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text = label, color = if (selected) Color.White else TextPrimary, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun PowerUpTab(inventory: Map<PowerUpType, Int>, coins: Int, onBuy: (PowerUpType) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        items(PowerUpType.entries) { type ->
            val owned = inventory[type] ?: 0
            val canAfford = coins >= type.coinCost
            ShopRow(
                title = type.displayName,
                description = powerUpDescription(type),
                swatch = { Box(modifier = it.background(BubblePurple, CircleShape)) },
                statusText = "Owned: $owned",
                price = type.coinCost,
                buttonLabel = "BUY",
                buttonEnabled = canAfford,
                onBuyClick = { onBuy(type) }
            )
        }
    }
}

private fun powerUpDescription(type: PowerUpType): String = when (type) {
    PowerUpType.BOMB -> "Destroys bubbles around where you tap."
    PowerUpType.LIGHTNING -> "Clears an entire row of bubbles."
    PowerUpType.RAINBOW -> "Clears every bubble of the color you tap."
    PowerUpType.FIREBALL -> "Clears an entire column of bubbles."
}

@Composable
private fun CosmeticTab(
    items: List<CosmeticItem>,
    owned: Set<String>,
    selected: String,
    coins: Int,
    onBuy: (CosmeticItem) -> Unit,
    onSelect: (CosmeticItem) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        items(items) { item ->
            val isOwned = owned.contains(item.id)
            val isSelected = selected == item.id
            val canAfford = coins >= item.price
            ShopRow(
                title = item.displayName,
                description = if (isSelected) "Currently selected" else if (isOwned) "Owned — tap to select" else "Locked",
                swatch = { modifier ->
                    Box(
                        modifier = modifier
                            .background(Brush.verticalGradient(item.previewColors.ifEmpty { listOf(LockedGray) }), CircleShape)
                    )
                },
                statusText = if (isSelected) "SELECTED" else if (isOwned) "OWNED" else "",
                price = item.price,
                buttonLabel = if (isOwned) { if (isSelected) "SELECTED" else "SELECT" } else "UNLOCK",
                buttonEnabled = isOwned || canAfford,
                buttonColor = if (isOwned && !isSelected) BubbleGreen else null,
                onBuyClick = { if (isOwned) onSelect(item) else onBuy(item) }
            )
        }
    }
}

@Composable
private fun ShopRow(
    title: String,
    description: String,
    swatch: @Composable (Modifier) -> Unit,
    statusText: String,
    price: Int,
    buttonLabel: String,
    buttonEnabled: Boolean,
    buttonColor: Color? = null,
    onBuyClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        swatch(Modifier.size(48.dp))
        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            Text(text = description, style = MaterialTheme.typography.bodyLarge, color = TextPrimary.copy(alpha = 0.6f))
            if (statusText.isNotEmpty()) {
                Text(text = statusText, style = MaterialTheme.typography.bodyLarge, color = BubblePurple)
            }
        }
        RoundedGameButton(
            text = if (price > 0 && buttonLabel == "UNLOCK") "$buttonLabel \uD83D\uDCB0$price" else buttonLabel,
            baseColor = if (!buttonEnabled) LockedGray else (buttonColor ?: BubblePurple),
            modifier = Modifier.width(110.dp),
            height = 48.dp,
            onClick = { if (buttonEnabled) onBuyClick() }
        )
    }
}
