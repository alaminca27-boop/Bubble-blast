package com.bubbleblastbangla.ui.gameover

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubbleBlue
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.HeartRed
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.SurfaceCardMuted
import com.bubbleblastbangla.ui.theme.TextPrimary

/**
 * Game Over screen (spec section 10). A heart was already deducted by
 * GameplayViewModel before navigating here (spec section 14). The
 * "Continue" rewarded-ad recovery is intentionally shown disabled: no ad
 * network is wired up until Phase 6, and spec section 23 requires ads to
 * never be mandatory and to fail gracefully offline — a disabled button
 * with a clear label satisfies that without faking a working ad flow.
 */
@Composable
fun GameOverScreen(
    levelNumber: Int,
    score: Int,
    onHome: () -> Unit,
    onRetry: () -> Unit
) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    val bestScore = progress.bestScorePerLevel[levelNumber] ?: 0

    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as com.bubbleblastbangla.app.BubbleBlastApplication
    LaunchedEffect(Unit) { app.audio.playMusic(com.bubbleblastbangla.audio.MusicTrack.GAME_OVER) }
    LaunchedEffect(Unit) { progressRepository.refreshHeartRegen() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceCardMuted)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "GAME OVER",
            style = MaterialTheme.typography.displayLarge,
            fontWeight = FontWeight.ExtraBold,
            color = HeartRed
        )
        com.bubbleblastbangla.ui.components.PandaMascot(
            size = 80.dp,
            modifier = Modifier.size(80.dp),
            mood = com.bubbleblastbangla.ui.components.PandaMood.SAD
        )
        Text(
            text = "Out of shots — Level $levelNumber",
            style = MaterialTheme.typography.bodyLarge,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(24.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StatRow(label = "Score", value = score.toString())
            StatRow(label = "Best Score", value = bestScore.toString())
            StatRow(label = "Hearts Left", value = progress.hearts.toString(), valueColor = HeartRed)
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Optional ad-based recovery — disabled until the modular ads architecture (Phase 6) exists.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xFFD9D9E3))
                .padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "CONTINUE (Watch Ad)", style = MaterialTheme.typography.labelLarge, color = TextPrimary.copy(alpha = 0.5f))
            Text(text = "Not available offline", style = MaterialTheme.typography.bodyLarge, color = TextPrimary.copy(alpha = 0.4f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        val canRetry = progress.hearts > 0
        RoundedGameButton(
            text = "RETRY",
            baseColor = BubbleBlue,
            onClick = onRetry
        )
        if (!canRetry) {
            Text(
                text = "No hearts left — they regenerate over time, or you can still retry now",
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary.copy(alpha = 0.6f),
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        RoundedGameButton(text = "HOME", baseColor = BubblePurple, onClick = onHome)
    }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        Text(text = value, style = MaterialTheme.typography.titleLarge, color = valueColor, fontWeight = FontWeight.Bold)
    }
}
