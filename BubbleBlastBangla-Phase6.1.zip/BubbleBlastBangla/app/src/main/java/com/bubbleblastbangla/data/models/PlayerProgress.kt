package com.bubbleblastbangla.data.models

/**
 * Everything about the player that must survive an app restart (spec
 * section 15). Immutable snapshot — [com.bubbleblastbangla.data.repository.ProgressRepository]
 * holds the current one in a StateFlow and produces new copies on change.
 */
data class PlayerProgress(
    val coins: Int = 0,
    val hearts: Int = 5,
    val maxHearts: Int = 5,
    val highestUnlockedLevel: Int = 1,
    val starsPerLevel: Map<Int, Int> = emptyMap(),
    val bestScorePerLevel: Map<Int, Int> = emptyMap(),
    val powerUpInventory: Map<PowerUpType, Int> = mapOf(
        PowerUpType.BOMB to 0,
        PowerUpType.LIGHTNING to 0,
        PowerUpType.RAINBOW to 0,
        PowerUpType.FIREBALL to 0
    ),
    val musicOn: Boolean = true,
    val soundOn: Boolean = true,
    val vibrationOn: Boolean = true,
    val selectedTheme: String = "forest",
    val selectedBubbleSkin: String = "classic",
    val ownedThemes: Set<String> = setOf("forest"),
    val ownedBubbleSkins: Set<String> = setOf("classic"),
    /** 1-7, the day the player is next eligible to claim (spec section 13). */
    val dailyRewardDay: Int = 1,
    /** Epoch day (days since 1970-01-01) the reward was last claimed, or null if never claimed. */
    val dailyRewardLastClaimEpochDay: Long? = null,
    /** Wall-clock start of the current heart-regeneration countdown (epoch millis), or null when hearts are already full (spec section 14). */
    val heartRegenStartEpochMillis: Long? = null,
    /** ISO 639-1 code. Only "en" is actually supported today — see SettingsScreen — but the field exists now so a real picker is a UI-only change later. */
    val language: String = "en"
)
