package com.bubbleblastbangla.navigation

/**
 * Every navigable destination in the app. Kept as a sealed class (not raw
 * strings scattered around) so adding a new screen later, or adding
 * arguments (e.g. levelId) to an existing one, is a compile-time-checked
 * change in one place.
 */
sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object LevelMap : Screen("level_map")
    data object Tutorial : Screen("tutorial")
    data object Shop : Screen("shop")
    data object DailyReward : Screen("daily_reward")
    data object Settings : Screen("settings")

    // Gameplay and its two outcome screens take a levelNumber argument.
    data object Gameplay : Screen("gameplay/{levelNumber}") {
        fun createRoute(levelNumber: Int) = "gameplay/$levelNumber"
        const val ARG_LEVEL_NUMBER = "levelNumber"
    }

    data object LevelComplete : Screen("level_complete/{levelNumber}/{score}/{stars}/{coins}") {
        fun createRoute(levelNumber: Int, score: Int, stars: Int, coins: Int) =
            "level_complete/$levelNumber/$score/$stars/$coins"
        const val ARG_LEVEL_NUMBER = "levelNumber"
        const val ARG_SCORE = "score"
        const val ARG_STARS = "stars"
        const val ARG_COINS = "coins"
    }

    data object GameOver : Screen("game_over/{levelNumber}/{score}") {
        fun createRoute(levelNumber: Int, score: Int) = "game_over/$levelNumber/$score"
        const val ARG_LEVEL_NUMBER = "levelNumber"
        const val ARG_SCORE = "score"
    }
}
