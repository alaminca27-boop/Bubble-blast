package com.bubbleblastbangla.data.models

import androidx.compose.ui.graphics.Color

/**
 * A purchasable/selectable cosmetic item (spec section 12: Shop "Bubbles"
 * and "Themes" categories). Both catalogs below use this one model so
 * adding a new skin or theme later is a single new entry, not new code.
 */
data class CosmeticItem(
    val id: String,
    val displayName: String,
    val price: Int,
    val previewColors: List<Color>,
    val ownedByDefault: Boolean = false
)

/** Original, non-copyrighted theme names/palettes (spec section 12 examples; spec section 21 forbids copyrighted IP). */
object ThemeCatalog {
    val all = listOf(
        CosmeticItem("forest", "Forest", price = 0, previewColors = listOf(Color(0xFF2FB88A), Color(0xFF1E8F6B)), ownedByDefault = true),
        CosmeticItem("snow", "Snow Mountain", price = 400, previewColors = listOf(Color(0xFFAFD8E8), Color(0xFF6FA8C9))),
        CosmeticItem("desert", "Desert", price = 400, previewColors = listOf(Color(0xFFF2C879), Color(0xFFD98E4A))),
        CosmeticItem("space", "Space", price = 600, previewColors = listOf(Color(0xFF2B2140), Color(0xFF0E0A1A))),
        CosmeticItem("candy", "Candy World", price = 600, previewColors = listOf(Color(0xFFFF9EC4), Color(0xFFB06AFF)))
    )

    fun colorsFor(themeId: String): List<Color> = all.find { it.id == themeId }?.previewColors ?: all.first().previewColors
}

/** Original bubble skin palette/finish names (spec section 12 examples). */
object BubbleSkinCatalog {
    val all = listOf(
        CosmeticItem("classic", "Classic", price = 0, previewColors = listOf(Color(0xFFFF5A5F)), ownedByDefault = true),
        CosmeticItem("candy", "Candy", price = 300, previewColors = listOf(Color(0xFFFF9EC4))),
        CosmeticItem("galaxy", "Galaxy", price = 500, previewColors = listOf(Color(0xFF6A4CFF))),
        CosmeticItem("neon", "Neon", price = 500, previewColors = listOf(Color(0xFF39FF88))),
        CosmeticItem("rainbow", "Rainbow", price = 700, previewColors = listOf(Color(0xFFFF5A5F), Color(0xFFFFD44C), Color(0xFF4CD97B), Color(0xFF4CA6FF)))
    )
}
