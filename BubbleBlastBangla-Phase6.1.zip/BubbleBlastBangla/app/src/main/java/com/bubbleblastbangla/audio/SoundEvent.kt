package com.bubbleblastbangla.audio

/**
 * Every sound effect the game can play (spec section 18 / Phase 6 item 1).
 * [rawResName] is the expected filename (no extension) under
 * `res/raw/` — e.g. SoundEvent.BUBBLE_POP expects `res/raw/sfx_bubble_pop.*`.
 *
 * No actual audio files ship with this project (Phase 6 explicitly forbids
 * downloading or fabricating copyrighted/placeholder audio). [SoundManager]
 * looks these names up by string at runtime and silently skips playback if
 * the resource isn't there, so the app builds and runs correctly with zero
 * audio files — drop in files with these exact names under `res/raw/` and
 * they start playing with no code changes.
 */
enum class SoundEvent(val rawResName: String) {
    BUTTON_CLICK("sfx_button_click"),
    BUBBLE_SHOT("sfx_bubble_shot"),
    BUBBLE_COLLISION("sfx_bubble_collision"),
    BUBBLE_MATCH("sfx_bubble_match"),
    BUBBLE_POP("sfx_bubble_pop"),
    BUBBLE_FALL("sfx_bubble_fall"),
    POWER_UP_PURCHASE("sfx_powerup_purchase"),
    POWER_UP_ACTIVATE("sfx_powerup_activate"),
    COIN_REWARD("sfx_coin_reward"),
    STAR_EARNED("sfx_star_earned"),
    LEVEL_COMPLETE("sfx_level_complete"),
    GAME_OVER("sfx_game_over"),
    DAILY_REWARD("sfx_daily_reward"),
    ERROR("sfx_error")
}

/** Background music tracks (spec section 18). Same no-file-required behavior as [SoundEvent]. */
enum class MusicTrack(val rawResName: String) {
    HOME("music_home"),
    LEVEL_MAP("music_level_map"),
    GAMEPLAY("music_gameplay"),
    LEVEL_COMPLETE("music_level_complete"),
    GAME_OVER("music_game_over")
}
