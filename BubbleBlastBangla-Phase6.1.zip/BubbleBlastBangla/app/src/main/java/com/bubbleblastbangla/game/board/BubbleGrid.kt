package com.bubbleblastbangla.game.board

import com.bubbleblastbangla.game.model.BubbleColor

/**
 * Mutable board state: which color (if any) occupies each cell.
 *
 * [rows]/[cols] bound the playable area. Odd rows have the same [cols] count
 * for simplicity, but their last column is geometrically off the right edge
 * of the board (see GridMath) and is simply never populated.
 */
class BubbleGrid(val rows: Int, val cols: Int) {

    private val cells = HashMap<CellCoord, BubbleColor>()

    fun colorAt(cell: CellCoord): BubbleColor? = cells[cell]

    fun isOccupied(cell: CellCoord): Boolean = cells.containsKey(cell)

    fun isInBounds(cell: CellCoord): Boolean =
        cell.row in 0 until rows && cell.col in 0 until cols

    fun set(cell: CellCoord, color: BubbleColor) {
        cells[cell] = color
    }

    fun remove(cell: CellCoord) {
        cells.remove(cell)
    }

    fun isEmpty(): Boolean = cells.isEmpty()

    fun occupiedCells(): Set<CellCoord> = cells.keys.toSet()

    /** All distinct colors currently on the board — used by Shooter to only load colors that are still matchable. */
    fun distinctColors(): Set<BubbleColor> = cells.values.toSet()

    /** Read-only snapshot for the UI layer to observe/render. */
    fun snapshot(): Map<CellCoord, BubbleColor> = cells.toMap()

    /** Loads a starting layout, e.g. from a LevelConfig in Phase 4. Clears any existing state first. */
    fun loadLayout(layout: Map<CellCoord, BubbleColor>) {
        cells.clear()
        cells.putAll(layout)
    }
}
