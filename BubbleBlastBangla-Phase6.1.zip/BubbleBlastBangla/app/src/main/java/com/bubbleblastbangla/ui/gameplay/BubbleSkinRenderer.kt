package com.bubbleblastbangla.ui.gameplay

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope

/**
 * Draws one bubble according to the player's selected Shop skin (spec
 * section 12 "Bubble Skins" / Phase 5.1 item 1). This is the single place
 * that turns a skin id into pixels — adding a new skin later means adding
 * one new `"id" ->` branch here (plus a matching [com.bubbleblastbangla.data.models.BubbleSkinCatalog]
 * entry), nothing else in gameplay changes.
 *
 * Skins are visual only, exactly as spec'd: the underlying [baseColor]
 * (from the game engine's color-matching logic) is always what's actually
 * matched/scored — skins never change gameplay, only how that same color
 * is painted.
 */
object BubbleSkinRenderer {

    fun drawBubble(scope: DrawScope, skinId: String, baseColor: Color, center: Offset, radius: Float) {
        when (skinId) {
            "candy" -> drawCandy(scope, baseColor, center, radius)
            "galaxy" -> drawGalaxy(scope, baseColor, center, radius)
            "neon" -> drawNeon(scope, baseColor, center, radius)
            "rainbow" -> drawRainbow(scope, baseColor, center, radius)
            else -> drawClassic(scope, baseColor, center, radius) // "classic" and any unrecognized id
        }
    }

    private fun drawClassic(scope: DrawScope, color: Color, center: Offset, radius: Float) {
        scope.drawCircle(color = color, radius = radius, center = center)
        // A small glossy highlight — matches the "glossy bubble effects" called for across the spec.
        scope.drawCircle(color = Color.White.copy(alpha = 0.35f), radius = radius * 0.28f, center = center + Offset(-radius * 0.3f, -radius * 0.3f))
    }

    private fun drawCandy(scope: DrawScope, color: Color, center: Offset, radius: Float) {
        scope.drawCircle(color = color, radius = radius, center = center)
        scope.drawCircle(color = Color.White.copy(alpha = 0.55f), radius = radius * 0.5f, center = center)
        scope.drawCircle(color = color, radius = radius * 0.22f, center = center)
    }

    private fun drawGalaxy(scope: DrawScope, color: Color, center: Offset, radius: Float) {
        val gradient = Brush.radialGradient(
            colors = listOf(Color(0xFF0E0A1A), color),
            center = center,
            radius = radius
        )
        scope.drawCircle(brush = gradient, radius = radius, center = center)
        scope.drawCircle(color = Color.White.copy(alpha = 0.8f), radius = radius * 0.06f, center = center + Offset(radius * 0.35f, -radius * 0.25f))
        scope.drawCircle(color = Color.White.copy(alpha = 0.6f), radius = radius * 0.04f, center = center + Offset(-radius * 0.25f, radius * 0.3f))
    }

    private fun drawNeon(scope: DrawScope, color: Color, center: Offset, radius: Float) {
        scope.drawCircle(color = color.copy(alpha = 0.35f), radius = radius * 1.15f, center = center) // outer glow
        scope.drawCircle(color = Color(0xFF14181A), radius = radius, center = center)
        scope.drawCircle(color = color, radius = radius, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = radius * 0.18f))
    }

    private fun drawRainbow(scope: DrawScope, color: Color, center: Offset, radius: Float) {
        val gradient = Brush.sweepGradient(
            colors = listOf(
                Color(0xFFFF5A5F), Color(0xFFFFD44C), Color(0xFF4CD97B),
                Color(0xFF4CA6FF), Color(0xFFB06AFF), Color(0xFFFF5A5F)
            ),
            center = center
        )
        scope.drawCircle(brush = gradient, radius = radius, center = center)
        // A ring of the bubble's true match-color keeps color identity readable at a glance.
        scope.drawCircle(color = color, radius = radius, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = radius * 0.22f))
    }
}
