package com.bubbleblastbangla.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import com.bubbleblastbangla.ui.theme.CoinGold
import com.bubbleblastbangla.ui.theme.HeartRed
import com.bubbleblastbangla.ui.theme.SurfaceCard

/**
 * Pill-shaped counter used for coins and hearts in the top bar of Home,
 * Level Map, Shop, and Gameplay (spec: "Coin counter" / "Heart/life counter").
 *
 * A colored dot stands in for the coin/heart icon until real art assets are
 * added — swapping in an Image/Icon later only touches this one composable.
 *
 * [label] drives a merged accessibility description (e.g. "Coins: 250")
 * instead of a screen reader announcing just the bare number (Phase 6 item
 * 13: "avoid relying only on color to communicate important states" — the
 * dot color alone doesn't tell a screen-reader user coins from hearts).
 */
@Composable
fun CounterChip(
    value: Int,
    dotColor: Color,
    label: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(SurfaceCard)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clearAndSetSemantics { contentDescription = "$label: $value" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Box(modifier = Modifier.width(6.dp))
        Text(text = value.toString(), style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun CoinCounter(coins: Int, modifier: Modifier = Modifier) {
    CounterChip(value = coins, dotColor = CoinGold, label = "Coins", modifier = modifier)
}

@Composable
fun HeartCounter(hearts: Int, modifier: Modifier = Modifier) {
    CounterChip(value = hearts, dotColor = HeartRed, label = "Hearts", modifier = modifier)
}
