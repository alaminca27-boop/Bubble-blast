package com.bubbleblastbangla.game.matching

import com.bubbleblastbangla.game.board.BubbleGrid
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath

/**
 * Finds the connected same-color cluster containing a given cell (spec
 * section 5: "3 matching bubbles = destroy"). Pure breadth-first search over
 * grid neighbors — no engine/physics needed, matching bubble-shooter
 * convention.
 */
object MatchFinder {

    /** Returns every cell connected to [start] (inclusive) that shares its color. */
    fun clusterOf(grid: BubbleGrid, gridMath: GridMath, start: CellCoord): Set<CellCoord> {
        val color = grid.colorAt(start) ?: return emptySet()
        val visited = mutableSetOf(start)
        val queue = ArrayDeque<CellCoord>().apply { add(start) }

        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            for (neighbor in gridMath.neighborsOf(current)) {
                if (neighbor in visited) continue
                if (!grid.isInBounds(neighbor)) continue
                if (grid.colorAt(neighbor) != color) continue
                visited += neighbor
                queue += neighbor
            }
        }
        return visited
    }
}
