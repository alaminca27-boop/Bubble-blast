package com.bubbleblastbangla.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val BubbleBlastColorScheme = lightColorScheme(
    primary = BubblePurple,
    secondary = BubbleBlue,
    tertiary = BubbleOrange,
    background = SurfaceCardMuted,
    surface = SurfaceCard,
    onPrimary = TextOnDark,
    onSecondary = TextOnDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = HeartRed
)

/**
 * Root theme applied once in MainActivity. Keeps colors/typography centralized
 * so every screen (Home, Level Map, Shop, ...) stays visually consistent
 * (spec section 20: "Use a consistent visual system").
 *
 * NOTE: a real rounded/friendly display font (e.g. Baloo 2, Fredoka) should be
 * dropped into res/font/ and referenced from Type.kt during the art pass —
 * using the system font for now keeps Phase 2 dependency-free.
 */
@Composable
fun BubbleBlastBanglaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BubbleBlastColorScheme,
        typography = BubbleBlastTypography,
        content = content
    )
}
