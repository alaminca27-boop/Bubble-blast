package com.bubbleblastbangla.data.models

/**
 * What a level requires the player to accomplish (spec section 7: "Target").
 * CLEAR_ALL is what Phase 3's temporary default session used; SCORE_TARGET
 * and COLOR_TARGET are added now that real LevelConfig exists. Obstacles
 * (spec section 7, "Level 20: Obstacles") are tracked separately on
 * [LevelConfig.obstacles] and are read by the board loader but not yet
 * given special break-through mechanics — that's flagged as a Phase 7
 * follow-up rather than expanded here, to keep this phase's scope to what
 * the plan asked for (levels/stars/coins/power-ups/save).
 */
enum class TargetType {
    CLEAR_ALL,
    SCORE_TARGET,
    COLOR_TARGET
}
