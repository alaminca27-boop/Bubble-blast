package com.bubbleblastbangla.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.bubbleblastbangla.app.BubbleBlastApplication
import com.bubbleblastbangla.data.repository.ProgressRepository

/**
 * Gives any screen access to the single app-wide [ProgressRepository]
 * (coins, hearts, unlocked levels, stars, power-up inventory, settings —
 * spec section 15). Pair with `.progress.collectAsState()` to observe it
 * reactively:
 *
 * ```
 * val repository = rememberProgressRepository()
 * val progress by repository.progress.collectAsState()
 * ```
 */
@Composable
fun rememberProgressRepository(): ProgressRepository {
    val context = LocalContext.current
    return remember { (context.applicationContext as BubbleBlastApplication).progressRepository }
}
