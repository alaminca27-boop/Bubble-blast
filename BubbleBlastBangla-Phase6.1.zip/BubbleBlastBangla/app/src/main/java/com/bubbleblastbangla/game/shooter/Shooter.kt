package com.bubbleblastbangla.game.shooter

import com.bubbleblastbangla.game.model.BubbleColor

/**
 * Holds the current shooting bubble and the next-bubble preview (spec
 * section 4: "Current shooting bubble" / "Next bubble preview").
 *
 * [availableColors] should be the set of colors still present on the board
 * (BubbleGrid.distinctColors()) so the shooter never loads a color that can
 * no longer match anything — a standard bubble-shooter fairness rule.
 */
class Shooter(availableColors: Set<BubbleColor>, private val random: kotlin.random.Random = kotlin.random.Random.Default) {

    var current: BubbleColor = pickRandom(availableColors)
        private set
    var next: BubbleColor = pickRandom(availableColors)
        private set

    /** Call after a bubble is fired: promotes [next] to [current] and rolls a new [next]. */
    fun advance(availableColors: Set<BubbleColor>) {
        current = next
        next = pickRandom(availableColors)
    }

    private fun pickRandom(colors: Set<BubbleColor>): BubbleColor {
        val pool = colors.ifEmpty { BubbleColor.entries.toSet() }
        return pool.elementAt(random.nextInt(pool.size))
    }
}
