package com.bubbleblastbangla.ui.tutorial

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubbleBlueGame
import com.bubbleblastbangla.ui.theme.BubbleGreen
import com.bubbleblastbangla.ui.theme.BubbleGreenGame
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.BubblePurpleGame
import com.bubbleblastbangla.ui.theme.BubbleRed
import com.bubbleblastbangla.ui.theme.BubbleYellowGame
import com.bubbleblastbangla.ui.theme.LockedGray
import com.bubbleblastbangla.ui.theme.SurfaceCardMuted
import com.bubbleblastbangla.ui.theme.TextPrimary

private data class TutorialPage(val title: String, val body: String, val swatch: Color)

private val PAGES = listOf(
    TutorialPage("Aim", "Drag on the board to aim, then release to shoot the bubble.", BubbleRed),
    TutorialPage("Match", "Match 3 or more bubbles of the same color to pop them.", BubbleGreenGame),
    TutorialPage("Fall", "Bubbles left floating with no support above them fall automatically.", BubbleBlueGame),
    TutorialPage("Bomb", "Destroys every bubble around the spot you tap.", BubblePurple),
    TutorialPage("Lightning", "Clears a whole row of bubbles at once.", BubbleYellowGame),
    TutorialPage("Rainbow", "Clears every bubble of the color you tap on the board.", BubblePurpleGame),
    TutorialPage("Fire Ball", "Clears an entire column of bubbles.", BubbleRed),
    TutorialPage("Win", "Clear the target to finish the level and earn stars and coins!", BubbleGreen)
)

/**
 * How To Play / Tutorial screen (spec section 17): 8 short pages with a
 * simple color swatch "illustration" (no external art assets needed), a
 * progress indicator, and Next/Previous/Skip — no large paragraphs.
 */
@Composable
fun TutorialScreen(onFinish: () -> Unit) {
    var pageIndex by remember { mutableIntStateOf(0) }
    val page = PAGES[pageIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceCardMuted)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text(
                text = "Skip",
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary.copy(alpha = 0.6f),
                modifier = Modifier
                    .padding(8.dp)
                    .clickable(onClick = onFinish)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Canvas(modifier = Modifier.size(120.dp)) {
            drawCircle(color = page.swatch)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(text = page.title, style = MaterialTheme.typography.headlineMedium, color = TextPrimary, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = page.body, style = MaterialTheme.typography.bodyLarge, color = TextPrimary, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(20.dp))

        Row {
            PAGES.indices.forEach { i ->
                Box(
                    modifier = Modifier
                        .padding(3.dp)
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(if (i == pageIndex) BubblePurple else LockedGray)
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RoundedGameButton(
                text = "PREV",
                baseColor = if (pageIndex > 0) BubblePurple else LockedGray,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
                onClick = { if (pageIndex > 0) pageIndex-- }
            )
            RoundedGameButton(
                text = if (pageIndex == PAGES.lastIndex) "DONE" else "NEXT",
                baseColor = BubbleGreen,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
                onClick = {
                    if (pageIndex == PAGES.lastIndex) onFinish() else pageIndex++
                }
            )
        }
    }
}
