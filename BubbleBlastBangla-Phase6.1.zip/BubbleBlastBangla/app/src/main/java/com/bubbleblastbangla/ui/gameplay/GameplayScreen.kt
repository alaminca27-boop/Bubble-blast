package com.bubbleblastbangla.ui.gameplay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bubbleblastbangla.app.BubbleBlastApplication
import com.bubbleblastbangla.audio.MusicTrack
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.SurfaceCardMuted
import com.bubbleblastbangla.ui.theme.TextPrimary

/**
 * The real Gameplay screen. Renders the bubble board, current + next
 * shooting bubbles, a dotted aim trajectory, and handles touch drag-to-aim /
 * release-to-shoot (Phase 3). Phase 4 adds: a real per-level [com.bubbleblastbangla.data.models.LevelConfig],
 * a power-up bar backed by the player's actual inventory, and coin/star
 * rewards written through [com.bubbleblastbangla.data.repository.ProgressRepository]
 * on level clear or heart loss on failure.
 */
@Composable
fun GameplayScreen(
    levelNumber: Int,
    onBack: () -> Unit,
    onLevelComplete: (score: Int, stars: Int, coins: Int) -> Unit,
    onGameOver: (score: Int) -> Unit,
    viewModel: GameplayViewModel = viewModel()
) {
    var boardSizePx by remember { mutableStateOf(Offset.Zero) }
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    val context = LocalContext.current
    val app = context.applicationContext as BubbleBlastApplication

    // Phase 6: real audio/haptic hooks (were no-op through Phase 4/5) + gameplay music.
    LaunchedEffect(Unit) {
        viewModel.audioHooks = RealGameplayAudioHooks(app.audio, app.haptics)
        app.audio.playMusic(MusicTrack.GAMEPLAY)
    }

    // Drives the particle system only while particles are actually alive —
    // idles on a cheap poll otherwise so this never burns a frame callback
    // every ~16ms for the whole time the player is on this screen (Phase 6
    // item 11: "avoid... heavy work on the main/UI thread").
    var particleTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        var lastFrameNanos = 0L
        while (true) {
            if (viewModel.particleSystem.isIdle()) {
                lastFrameNanos = 0L
                kotlinx.coroutines.delay(100)
                continue
            }
            val now = withFrameNanos { it }
            val dt = if (lastFrameNanos == 0L) 0f else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastFrameNanos = now
            viewModel.particleSystem.update(dt)
            particleTick++
        }
    }

    LaunchedEffect(viewModel.levelResult) {
        when (viewModel.levelResult) {
            LevelResult.CLEARED -> onLevelComplete(viewModel.score, viewModel.starsEarned, viewModel.coinsEarned)
            LevelResult.OUT_OF_SHOTS -> onGameOver(viewModel.score)
            null -> Unit
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceCardMuted)
            .statusBarsPadding()
    ) {
        // Top bar: score, shots remaining, level number, pause/back.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "Level $levelNumber", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                Text(text = "Score: ${viewModel.score}", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            }
            Text(
                text = "Shots: ${viewModel.shotsRemaining}",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            RoundedGameButton(
                text = "PAUSE",
                baseColor = BubblePurple,
                modifier = Modifier.width(96.dp),
                height = 44.dp,
                onClick = onBack
            )
        }

        if (viewModel.selectedPowerUp != null) {
            Text(
                text = "Tap a bubble to use ${viewModel.selectedPowerUp!!.displayName}",
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .padding(8.dp)
            )
        }

        viewModel.purchaseMessage?.let { message ->
            LaunchedEffect(message) {
                kotlinx.coroutines.delay(1800)
                viewModel.clearPurchaseMessage()
            }
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BubblePurple)
                    .padding(8.dp)
            )
        }

        // Bubble board — square-ish play area sized from measured width.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .padding(horizontal = 8.dp)
                .onSizeChanged { size ->
                    boardSizePx = Offset(size.width.toFloat(), size.height.toFloat())
                    if (size.width > 0 && size.height > 0) {
                        viewModel.initSession(levelNumber, progressRepository, size.width.toFloat(), size.height.toFloat())
                    }
                }
                .pointerInput(viewModel.selectedPowerUp) {
                    if (viewModel.selectedPowerUp != null) {
                        detectTapGestures { offset -> viewModel.onPowerUpTarget(offset) }
                    } else {
                        detectDragGestures(
                            onDrag = { change, _ ->
                                change.consume()
                                viewModel.onAim(change.position)
                            },
                            onDragEnd = { viewModel.onAimEnd() },
                            onDragCancel = { viewModel.onAimEnd() }
                        )
                    }
                }
        ) {
            val math = viewModel.boardMath
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (math == null) return@Canvas
                particleTick.let { } // reads particleTick so this draw scope is re-invoked on every particle tick (draw-phase snapshot read)

                // Grid bubbles
                for ((cell, color) in viewModel.gridState) {
                    val center = math.cellCenter(cell)
                    BubbleSkinRenderer.drawBubble(this, viewModel.skinId, color.toComposeColor(), Offset(center.x, center.y), math.radius * 0.94f)
                }

                // Aim trajectory (dotted line) — only while actively aiming a shot, not a power-up.
                if (viewModel.trajectoryPreview.size >= 2) {
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(viewModel.trajectoryPreview.first().x, viewModel.trajectoryPreview.first().y)
                        viewModel.trajectoryPreview.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(
                        path = path,
                        color = Color.White.copy(alpha = 0.85f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 4f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 14f))
                        )
                    )
                }

                // Flying bubble mid-shot
                viewModel.flyingBubble?.let { pos ->
                    BubbleSkinRenderer.drawBubble(this, viewModel.skinId, viewModel.flyingBubbleColor.toComposeColor(), pos, math.radius * 0.94f)
                }

                // Shooter (current bubble, stationary at anchor unless mid-flight)
                if (viewModel.flyingBubble == null) {
                    BubbleSkinRenderer.drawBubble(this, viewModel.skinId, viewModel.shooterColor.toComposeColor(), viewModel.shooterAnchor, math.radius * 0.94f)
                }

                // Particle bursts (pop/fall/power-up feedback — spec section 5)
                for (p in viewModel.particleSystem.particles) {
                    val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
                    drawCircle(color = p.color.copy(alpha = alpha), radius = p.radius * alpha, center = Offset(p.x, p.y))
                }

                // The popped bubble itself, shrinking and fading rather than vanishing instantly
                for (b in viewModel.particleSystem.poppingBubbles) {
                    val t = (b.age / b.maxAge).coerceIn(0f, 1f)
                    val scale = 1f - t
                    if (scale > 0f) {
                        drawCircle(color = b.color.copy(alpha = 1f - t), radius = b.baseRadius * scale, center = Offset(b.x, b.y))
                    }
                }
            }
        }

        // Bottom bar: next-bubble preview + power-up inventory (spec section 6).
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Next:", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                Box(modifier = Modifier.padding(start = 8.dp)) {
                    Canvas(modifier = Modifier.size(28.dp)) {
                        BubbleSkinRenderer.drawBubble(this, viewModel.skinId, viewModel.nextColor.toComposeColor(), center, size.minDimension / 2f)
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                PowerUpType.entries.forEach { type ->
                    PowerUpButton(
                        type = type,
                        count = progress.powerUpInventory[type] ?: 0,
                        isSelected = viewModel.selectedPowerUp == type,
                        onClick = { viewModel.onPowerUpButtonTap(type) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PowerUpButton(type: PowerUpType, count: Int, isSelected: Boolean, onClick: () -> Unit) {
    val bg = if (isSelected) BubblePurple else SurfaceCard
    val textColor = if (isSelected) Color.White else TextPrimary
    val feedback = com.bubbleblastbangla.ui.components.LocalGameFeedback.current
    var lastTapAtMillis by remember { mutableStateOf(0L) }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clickable {
                // Same debounce pattern as RoundedGameButton — power-ups are
                // an explicitly listed "important button" (spec section 8)
                // and this one isn't a RoundedGameButton, so it needs its
                // own protection against rapid double-tap.
                val now = System.currentTimeMillis()
                if (now - lastTapAtMillis < 400L) return@clickable
                lastTapAtMillis = now
                feedback.onButtonPress()
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = type.displayName, style = MaterialTheme.typography.bodyLarge, color = textColor)
            // Owned power-ups show the count; an empty inventory shows the
            // buy price instead — tapping either uses it or purchases one
            // (see GameplayViewModel.onPowerUpButtonTap).
            Text(
                text = if (count > 0) "x$count" else "\uD83D\uDCB0${type.coinCost}",
                style = MaterialTheme.typography.bodyLarge,
                color = textColor
            )
        }
    }
}
