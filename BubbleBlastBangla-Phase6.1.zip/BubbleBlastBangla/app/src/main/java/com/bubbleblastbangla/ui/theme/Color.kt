package com.bubbleblastbangla.ui.theme

import androidx.compose.ui.graphics.Color

// Core brand palette (spec section 20: Purple, Blue, Green, Yellow, Orange)
val BubblePurple = Color(0xFF7B4FE0)
val BubbleBlue = Color(0xFF3E9CFF)
val BubbleGreen = Color(0xFF3ED17A)
val BubbleYellow = Color(0xFFFFC93E)
val BubbleOrange = Color(0xFFFF8A3D)

val BackgroundForestTop = Color(0xFF2FB88A)
val BackgroundForestBottom = Color(0xFF1E8F6B)

val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardMuted = Color(0xFFF2F6FF)
val TextPrimary = Color(0xFF2B2140)
val TextOnDark = Color(0xFFFFFFFF)

val CoinGold = Color(0xFFFFD54A)
val HeartRed = Color(0xFFFF5C7A)

val LockedGray = Color(0xFFB9B9C6)

// Gameplay bubble colors (spec section 4)
val BubbleRed = Color(0xFFFF5A5F)
val BubbleBlueGame = Color(0xFF4CA6FF)
val BubbleGreenGame = Color(0xFF4CD97B)
val BubbleYellowGame = Color(0xFFFFD44C)
val BubblePurpleGame = Color(0xFFB06AFF)
