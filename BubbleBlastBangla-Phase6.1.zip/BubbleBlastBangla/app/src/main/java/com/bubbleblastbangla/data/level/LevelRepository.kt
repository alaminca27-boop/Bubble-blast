package com.bubbleblastbangla.data.level

import com.bubbleblastbangla.data.models.LevelConfig
import com.bubbleblastbangla.data.models.StarThresholds
import com.bubbleblastbangla.data.models.TargetType

/**
 * Produces a [LevelConfig] for any level number. Levels are generated from a
 * difficulty formula rather than hand-authored one by one, which satisfies
 * spec section 7 ("Do NOT hard-code all levels inside the gameplay code" /
 * "Store level configuration separately") while still giving the 100-level
 * progression the spec describes (more bubbles at 5, more colors at 10,
 * limited shots at 30, etc.) and making Level 101+ trivial to add — the
 * formula just keeps extrapolating, no new code needed.
 *
 * If hand-authored, fully custom levels are wanted later (e.g. hero/boss
 * levels with specific hand-placed obstacle layouts), the plan is to swap
 * this class's body for a JSON loader (assets/levels/*.json +
 * kotlinx.serialization, already a declared dependency) behind the same
 * [configFor] signature — callers never need to change.
 */
object LevelRepository {

    const val TOTAL_LEVELS = 100

    fun configFor(levelNumber: Int): LevelConfig {
        val n = levelNumber.coerceAtLeast(1)

        // Difficulty curve, loosely matching the spec's worked examples
        // (L1 simple/3 colors, L10 more colors, L20 obstacles, L30 limited
        // shots, L50 boss-style, L100 final mega challenge).
        val colorCount = when {
            n < 10 -> 3
            n < 30 -> 4
            else -> 5
        }
        val filledRows = (4 + n / 12).coerceIn(4, 9)
        val shotLimit = when {
            n < 30 -> 30 - n / 3          // generous early on
            n < 70 -> (24 - (n - 30) / 5) // tightens in the mid-game
            else -> 16
        }.coerceIn(14, 30)

        val isBossLevel = n % 50 == 0 // spec: Level 50 boss-style, Level 100 final mega challenge
        val targetType = if (isBossLevel) TargetType.SCORE_TARGET else TargetType.CLEAR_ALL
        val targetValue = if (isBossLevel) 1000 + n * 20 else 0

        val coinReward = (100 + n * 4).coerceAtMost(500)
        val baseScoreEstimate = filledRows * (colorCount + 4) * 12 // rough par score for this layout size
        val starThresholds = StarThresholds(
            twoStarScore = (baseScoreEstimate * 1.3).toInt(),
            threeStarScore = (baseScoreEstimate * 1.7).toInt()
        )

        return LevelConfig(
            levelNumber = n,
            filledRows = filledRows,
            colorCount = colorCount,
            shotLimit = shotLimit,
            targetType = targetType,
            targetValue = targetValue,
            coinReward = coinReward,
            starThresholds = starThresholds
        )
    }

    fun allLevelNumbers(): List<Int> = (1..TOTAL_LEVELS).toList()
}
