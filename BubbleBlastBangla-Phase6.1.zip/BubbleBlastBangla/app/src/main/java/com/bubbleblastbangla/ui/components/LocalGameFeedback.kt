package com.bubbleblastbangla.ui.components

import androidx.compose.runtime.staticCompositionLocalOf
import com.bubbleblastbangla.audio.GameAudioController
import com.bubbleblastbangla.audio.SoundEvent
import com.bubbleblastbangla.haptics.HapticManager

/**
 * Lets [RoundedGameButton] (and anything else) trigger the standard
 * button-press sound + haptic without every call site having to look up
 * and pass `GameAudioController`/`HapticManager` individually (spec section
 * 2/8 / Phase 6 items 2 & 8). Provided once near the root in MainActivity;
 * defaults to [Noop] so previews/tests that don't provide a real instance
 * never crash.
 */
interface GameFeedback {
    fun onButtonPress()

    object Noop : GameFeedback {
        override fun onButtonPress() {}
    }
}

class RealGameFeedback(private val audio: GameAudioController, private val haptics: HapticManager) : GameFeedback {
    override fun onButtonPress() {
        audio.playSfx(SoundEvent.BUTTON_CLICK)
        haptics.buttonPress()
    }
}

val LocalGameFeedback = staticCompositionLocalOf<GameFeedback> { GameFeedback.Noop }
