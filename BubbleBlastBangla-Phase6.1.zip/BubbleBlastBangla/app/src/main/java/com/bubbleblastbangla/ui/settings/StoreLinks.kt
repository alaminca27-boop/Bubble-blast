package com.bubbleblastbangla.ui.settings

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Real, minimal external-link handling for Settings (spec section 16 "Rate
 * Game" / "Privacy Policy"; Phase 5.1 item 3). Every entry point here is
 * wrapped so a device with no Play Store / no browser can never crash the
 * app — it just reports failure and the screen shows a friendly message.
 */
object StoreLinks {
    /** Must match applicationId in app/build.gradle.kts. */
    const val PLAY_STORE_PACKAGE_NAME = "com.bubbleblastbangla"

    /**
     * No production privacy policy exists yet. Leaving this null (rather
     * than a placeholder URL) means SettingsScreen shows an honest "not yet
     * published" state instead of a link that goes nowhere real — set this
     * to the real URL when one exists and the screen picks it up with no
     * other code changes.
     */
    val PRIVACY_POLICY_URL: String? = null

    /** Returns true if an app was actually launched to handle the request. */
    fun openPlayStoreListing(context: Context): Boolean {
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PLAY_STORE_PACKAGE_NAME"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: ActivityNotFoundException) {
            openUrl(context, "https://play.google.com/store/apps/details?id=$PLAY_STORE_PACKAGE_NAME")
        }
    }

    fun openUrl(context: Context, url: String): Boolean {
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
