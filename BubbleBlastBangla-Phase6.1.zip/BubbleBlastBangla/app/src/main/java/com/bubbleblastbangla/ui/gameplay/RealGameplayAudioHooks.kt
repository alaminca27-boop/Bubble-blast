package com.bubbleblastbangla.ui.gameplay

import com.bubbleblastbangla.audio.GameAudioController
import com.bubbleblastbangla.audio.SoundEvent
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.haptics.HapticManager

/**
 * The real implementation of [GameplayAudioHooks] (Phase 4's no-op
 * interface) — every real gameplay event now actually triggers a sound +
 * a light haptic (spec sections 2 & 18 / Phase 6 items 1 & 2). Wired in by
 * [GameplayScreen] via [GameplayViewModel.audioHooks].
 */
class RealGameplayAudioHooks(
    private val audio: GameAudioController,
    private val haptics: HapticManager
) : GameplayAudioHooks {
    override fun onShotFired() {
        audio.playSfx(SoundEvent.BUBBLE_SHOT)
        haptics.bubbleShot()
    }

    override fun onBubblesMatched(count: Int) {
        audio.playSfx(SoundEvent.BUBBLE_MATCH)
        haptics.matchSuccess()
    }

    override fun onBubblesFell(count: Int) {
        audio.playSfx(SoundEvent.BUBBLE_FALL)
    }

    override fun onPowerUpUsed(type: PowerUpType) {
        audio.playSfx(SoundEvent.POWER_UP_ACTIVATE)
        haptics.powerUpActivate()
    }

    override fun onPowerUpPurchased(type: PowerUpType) {
        audio.playSfx(SoundEvent.POWER_UP_PURCHASE)
        haptics.purchaseSuccess()
    }

    override fun onLevelCleared() {
        audio.playSfx(SoundEvent.LEVEL_COMPLETE)
        haptics.levelComplete()
    }

    override fun onLevelFailed() {
        audio.playSfx(SoundEvent.GAME_OVER)
        haptics.gameOver()
    }
}
