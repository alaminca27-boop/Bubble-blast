package com.bubbleblastbangla.ui.gameplay

import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** A bubble mid-pop: shrinks and fades over its lifetime instead of vanishing instantly (spec section 3: "Scale/pop animation... smooth disappearance"). */
class PoppingBubble(val x: Float, val y: Float, val color: Color, var age: Float, val maxAge: Float, val baseRadius: Float)

/** One simple physics-free particle: position, velocity, remaining life. */
class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val maxLife: Float, val color: Color, val radius: Float)

/**
 * A small, bounded, dependency-free particle system (spec section 5 /
 * Phase 6 item 5). Deliberately not a full particle *engine* — a plain
 * `ArrayList` updated once per frame and drawn straight into the gameplay
 * Canvas is enough for pop/power-up/falling feedback at this game's scale,
 * and keeps Phase 6 from pulling in a heavy dependency the spec explicitly
 * warns against.
 *
 * [maxParticles] hard-caps total particle count — spawning past the cap
 * drops the oldest particle first rather than growing unbounded, and every
 * particle is removed the instant its `life` reaches zero, so there is no
 * unbounded growth or leak even under continuous power-up spam.
 */
class ParticleSystem(private val maxParticles: Int = 150) {

    val particles = ArrayList<Particle>()
    val poppingBubbles = ArrayList<PoppingBubble>()

    /** The bubble itself, shrinking/fading in place — call once per popped cell, alongside [spawnBurst] for the particle burst. */
    fun spawnPop(x: Float, y: Float, color: Color, radius: Float, life: Float = 0.22f) {
        if (poppingBubbles.size >= maxParticles) poppingBubbles.removeAt(0)
        poppingBubbles.add(PoppingBubble(x, y, color, age = 0f, maxAge = life, baseRadius = radius))
    }

    fun spawnBurst(x: Float, y: Float, color: Color, count: Int = 8, speed: Float = 220f, life: Float = 0.45f, baseRadius: Float = 6f) {
        repeat(count) { i ->
            ensureCapacity()
            val angle = (i.toFloat() / count) * (2 * Math.PI).toFloat() + Random.nextFloat() * 0.6f
            val v = speed * (0.6f + Random.nextFloat() * 0.6f)
            particles.add(
                Particle(
                    x = x, y = y,
                    vx = cos(angle) * v, vy = sin(angle) * v,
                    life = life, maxLife = life,
                    color = color,
                    radius = baseRadius * (0.6f + Random.nextFloat() * 0.6f)
                )
            )
        }
    }

    private fun ensureCapacity() {
        if (particles.size >= maxParticles) particles.removeAt(0)
    }

    /** Advances every particle and popping bubble by [dtSeconds], removing anything expired. Call once per frame. */
    fun update(dtSeconds: Float) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.life -= dtSeconds
            if (p.life <= 0f) {
                iterator.remove()
                continue
            }
            p.x += p.vx * dtSeconds
            p.y += p.vy * dtSeconds
            p.vy += 420f * dtSeconds // gentle gravity so bursts settle rather than fly forever
            p.vx *= 0.97f
            p.vy *= 0.97f
        }

        val popIterator = poppingBubbles.iterator()
        while (popIterator.hasNext()) {
            val b = popIterator.next()
            b.age += dtSeconds
            if (b.age >= b.maxAge) popIterator.remove()
        }
    }

    /** True while there is nothing left to animate — lets the caller stop ticking frames entirely (see GameplayScreen's idle-poll loop). */
    fun isIdle(): Boolean = particles.isEmpty() && poppingBubbles.isEmpty()
}
