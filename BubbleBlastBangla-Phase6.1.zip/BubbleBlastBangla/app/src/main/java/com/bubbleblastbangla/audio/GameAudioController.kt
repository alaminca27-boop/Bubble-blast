package com.bubbleblastbangla.audio

import android.content.Context
import com.bubbleblastbangla.data.repository.ProgressRepository

/**
 * The one object every screen/ViewModel talks to for audio (spec section
 * 18 / Phase 6 item 1). Wraps [SoundManager] + [MusicManager] and checks
 * the existing `soundOn`/`musicOn` settings from [ProgressRepository] on
 * every call — no separate audio-settings store, per Phase 6's "do not
 * create duplicate systems" instruction.
 */
class GameAudioController(context: Context, private val progressRepository: ProgressRepository) {

    private val soundManager = SoundManager(context)
    private val musicManager = MusicManager(context)

    fun playSfx(event: SoundEvent) {
        if (progressRepository.progress.value.soundOn) soundManager.play(event)
    }

    fun playMusic(track: MusicTrack) {
        musicManager.setEnabled(progressRepository.progress.value.musicOn)
        musicManager.play(track)
    }

    /** Call whenever the Music toggle changes so playback reacts immediately (spec: "Toggle changes take effect immediately"). */
    fun onMusicSettingChanged(isOn: Boolean) {
        musicManager.setEnabled(isOn)
    }

    fun stopMusic() = musicManager.stop()

    fun release() {
        soundManager.release()
        musicManager.release()
    }
}
