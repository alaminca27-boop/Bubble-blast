package com.bubbleblastbangla.game.model

/**
 * The five gameplay bubble colors (spec section 4). This lives in the
 * game/ package (no Compose dependency) — the UI layer maps each value to
 * an actual androidx.compose.ui.graphics.Color for drawing (see
 * ui/gameplay/BubbleColorMapper.kt), keeping game logic renderer-agnostic.
 */
enum class BubbleColor {
    RED, BLUE, GREEN, YELLOW, PURPLE
}
