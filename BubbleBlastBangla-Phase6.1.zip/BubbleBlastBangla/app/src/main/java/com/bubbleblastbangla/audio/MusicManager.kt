package com.bubbleblastbangla.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log

/**
 * Plays looping background music, one track at a time (spec section 18).
 * Calling [play] with the track that's already playing is a deliberate
 * no-op — "Music should not restart unnecessarily during simple
 * navigation" — so re-entering the same screen (e.g. backing out of a
 * dialog) never causes an audible restart.
 *
 * Like [SoundManager], every operation is wrapped so a missing audio asset
 * degrades to silence instead of a crash.
 */
class MusicManager(private val context: Context) {

    private var player: MediaPlayer? = null
    private var currentTrack: MusicTrack? = null
    private var enabled = true

    fun play(track: MusicTrack) {
        if (!enabled) {
            currentTrack = track // remember what *should* play once re-enabled
            return
        }
        if (track == currentTrack && player?.isPlaying == true) return // already playing this track — don't restart

        stopInternal()
        currentTrack = track
        try {
            val resId = context.resources.getIdentifier(track.rawResName, "raw", context.packageName)
            if (resId == 0) return // no asset shipped for this track yet

            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                val afd = context.resources.openRawResourceFd(resId)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to play music ${track.name}: ${e.message}")
            stopInternal()
        }
    }

    /** Respects the Music ON/OFF setting (spec section 18) without forgetting what track should resume. */
    fun setEnabled(isEnabled: Boolean) {
        enabled = isEnabled
        if (!isEnabled) {
            stopInternal()
        } else {
            currentTrack?.let { play(it) }
        }
    }

    fun stop() {
        currentTrack = null
        stopInternal()
    }

    private fun stopInternal() {
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to stop music: ${e.message}")
        } finally {
            player = null
        }
    }

    fun release() = stopInternal()

    companion object {
        private const val TAG = "MusicManager"
    }
}
