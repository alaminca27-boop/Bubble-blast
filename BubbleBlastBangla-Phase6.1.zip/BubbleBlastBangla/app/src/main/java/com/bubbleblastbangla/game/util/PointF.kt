package com.bubbleblastbangla.game.util

import kotlin.math.sqrt

/**
 * Minimal 2D point/vector, used instead of androidx.compose.ui.geometry.Offset
 * so the game/ package stays free of any Compose/Android dependency (see
 * Phase 1 architecture note: "game/ has zero dependency on Compose/UI").
 * The UI layer converts PointF <-> Offset at the boundary
 * (ui/gameplay/GameplayViewModel.kt).
 */
data class PointF(val x: Float, val y: Float) {
    operator fun plus(other: PointF) = PointF(x + other.x, y + other.y)
    operator fun minus(other: PointF) = PointF(x - other.x, y - other.y)
    operator fun times(scalar: Float) = PointF(x * scalar, y * scalar)

    fun distanceTo(other: PointF): Float {
        val dx = x - other.x
        val dy = y - other.y
        return sqrt(dx * dx + dy * dy)
    }

    fun length(): Float = sqrt(x * x + y * y)

    fun normalized(): PointF {
        val len = length()
        return if (len == 0f) PointF(0f, 0f) else PointF(x / len, y / len)
    }
}
