package com.bubbleblastbangla.data.models

/** The four power-ups from spec section 6, with their fixed shop prices. */
enum class PowerUpType(val coinCost: Int, val displayName: String) {
    BOMB(500, "Bomb"),
    LIGHTNING(500, "Lightning"),
    RAINBOW(600, "Rainbow"),
    FIREBALL(700, "Fire Ball")
}
