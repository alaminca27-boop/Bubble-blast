package com.bubbleblastbangla.data.models

/** Fixed 7-day reward cycle (spec section 13). Day is 1-indexed. */
object DailyRewardCatalog {
    /** Pair of (coins, isBonusDay) for each of the 7 days. */
    val rewards: List<Pair<Int, Boolean>> = listOf(
        100 to false,
        150 to false,
        200 to false,
        250 to false,
        300 to false,
        350 to false,
        500 to true // Day 7: "500 coins + bonus"
    )

    fun coinsForDay(day: Int): Int = rewards.getOrElse((day - 1).coerceIn(0, 6)) { rewards[0] }.first
    fun isBonusDay(day: Int): Boolean = rewards.getOrElse((day - 1).coerceIn(0, 6)) { rewards[0] }.second
}
