package com.bubbleblastbangla.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.BubbleRed
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.SurfaceCardMuted
import com.bubbleblastbangla.ui.theme.TextPrimary

/**
 * Settings screen (spec section 16). Every toggle writes straight through
 * ProgressRepository.setSettings — no separate settings store — and takes
 * effect immediately since the UI observes the same StateFlow it wrote to.
 *
 * "Language" is an honest single-language row, not a fake picker — the
 * persisted `language` field on PlayerProgress exists so a real picker is a
 * UI-only addition later. "Rate Game" opens the real Play Store listing
 * (Play Store app if installed, browser fallback otherwise) and fails
 * silently-but-visibly rather than crashing if neither is available. "Privacy
 * Policy" is honest about not having a published URL yet rather than linking
 * to nothing — see StoreLinks.kt.
 */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    val context = LocalContext.current
    val app = context.applicationContext as com.bubbleblastbangla.app.BubbleBlastApplication
    var showResetConfirm by remember { mutableStateOf(false) }
    var showResetDone by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf<String?>(null) }

    feedback?.let { message ->
        LaunchedEffect(message) {
            kotlinx.coroutines.delay(2200)
            feedback = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceCardMuted)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Settings", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, fontWeight = FontWeight.ExtraBold)
        }

        feedback?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(BubblePurple)
                    .padding(10.dp)
            )
        }

        SettingToggle(
            label = "Music",
            checked = progress.musicOn,
            onCheckedChange = {
                progressRepository.setSettings(musicOn = it)
                app.audio.onMusicSettingChanged(it) // spec: "Toggle changes take effect immediately"
            }
        )
        SettingToggle(
            label = "Sound",
            checked = progress.soundOn,
            onCheckedChange = { progressRepository.setSettings(soundOn = it) }
        )
        SettingToggle(
            label = "Vibration",
            checked = progress.vibrationOn,
            onCheckedChange = { progressRepository.setSettings(vibrationOn = it) }
        )

        SettingRow(label = "Language", valueText = "English only", onClick = null)
        SettingRow(
            label = "Rate Game",
            valueText = "\u2605\u2605\u2605\u2605\u2605",
            onClick = {
                if (!StoreLinks.openPlayStoreListing(context)) {
                    feedback = "Couldn't open the Play Store on this device."
                }
            }
        )
        SettingRow(
            label = "Privacy Policy",
            valueText = if (StoreLinks.PRIVACY_POLICY_URL != null) "View" else "Not yet published",
            onClick = {
                val url = StoreLinks.PRIVACY_POLICY_URL
                if (url == null) {
                    feedback = "Privacy policy will be available before this game is published."
                } else if (!StoreLinks.openUrl(context, url)) {
                    feedback = "Couldn't open a browser on this device."
                }
            }
        )

        androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))

        RoundedGameButton(text = "RESET PROGRESS", baseColor = BubbleRed, onClick = { showResetConfirm = true })
        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(6.dp))
        RoundedGameButton(text = "BACK", baseColor = BubblePurple, onClick = onBack)
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset all progress?") },
            text = {
                Text(
                    "This permanently deletes your coins, unlocked levels, stars, " +
                        "best scores, power-ups, purchased themes/skins, and settings. " +
                        "This cannot be undone."
                )
            },
            confirmButton = {
                RoundedGameButton(
                    text = "DELETE",
                    baseColor = BubbleRed,
                    modifier = Modifier.width(130.dp).padding(4.dp),
                    height = 44.dp,
                    onClick = {
                        progressRepository.resetProgress()
                        showResetConfirm = false
                        showResetDone = true
                    }
                )
            },
            dismissButton = {
                RoundedGameButton(
                    text = "CANCEL",
                    baseColor = BubblePurple,
                    modifier = Modifier.width(110.dp).padding(4.dp),
                    height = 44.dp,
                    onClick = { showResetConfirm = false }
                )
            }
        )
    }

    if (showResetDone) {
        AlertDialog(
            onDismissRequest = { showResetDone = false },
            title = { Text("Progress reset") },
            text = { Text("Your progress has been reset to a fresh start.") },
            confirmButton = {
                RoundedGameButton(
                    text = "OK",
                    baseColor = BubblePurple,
                    modifier = Modifier.width(110.dp).padding(4.dp),
                    height = 44.dp,
                    onClick = { showResetDone = false }
                )
            }
        )
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCard)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = BubblePurple)
        )
    }
}

@Composable
private fun SettingRow(label: String, valueText: String, onClick: (() -> Unit)?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCard)
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        Text(text = valueText, style = MaterialTheme.typography.bodyLarge, color = TextPrimary.copy(alpha = 0.6f))
    }
}
