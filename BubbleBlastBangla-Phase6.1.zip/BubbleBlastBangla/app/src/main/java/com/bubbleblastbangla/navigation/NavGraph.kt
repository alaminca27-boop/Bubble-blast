package com.bubbleblastbangla.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.dailyreward.DailyRewardScreen
import com.bubbleblastbangla.ui.gameover.GameOverScreen
import com.bubbleblastbangla.ui.gameplay.GameplayScreen
import com.bubbleblastbangla.ui.home.HomeScreen
import com.bubbleblastbangla.ui.levelcomplete.LevelCompleteScreen
import com.bubbleblastbangla.ui.levelmap.LevelMapScreen
import com.bubbleblastbangla.ui.settings.SettingsScreen
import com.bubbleblastbangla.ui.shop.ShopScreen
import com.bubbleblastbangla.ui.tutorial.TutorialScreen

/**
 * Single source of truth for screen wiring. Every destination from
 * Screen.kt is registered here exactly once; screens themselves never hold
 * a NavController — they only receive lambdas — so screens stay
 * previewable/testable in isolation (see HomeScreen.kt).
 *
 * Phase 5: every destination is now a real screen — no PlaceholderScreen
 * remains anywhere in this graph. Level Complete / Game Over receive real
 * score/star/coin values as nav arguments rather than re-deriving them.
 */
@Composable
fun BubbleBlastNavGraph() {
    val navController = rememberNavController()
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()

    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                onPlayClick = {
                    // PLAY jumps into the player's next unlocked level (spec
                    // section 3) — real progress from ProgressRepository.
                    navController.navigate(Screen.Gameplay.createRoute(progress.highestUnlockedLevel))
                },
                onLevelMapClick = { navController.navigate(Screen.LevelMap.route) },
                onShopClick = { navController.navigate(Screen.Shop.route) },
                onDailyRewardClick = { navController.navigate(Screen.DailyReward.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) },
                onTutorialClick = { navController.navigate(Screen.Tutorial.route) }
            )
        }

        composable(Screen.LevelMap.route) {
            LevelMapScreen(
                onBack = { navController.popBackStack() },
                onLevelClick = { levelNumber -> navController.navigate(Screen.Gameplay.createRoute(levelNumber)) }
            )
        }

        composable(Screen.Tutorial.route) {
            TutorialScreen(onFinish = { navController.popBackStack() })
        }

        composable(Screen.Shop.route) {
            ShopScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.DailyReward.route) {
            DailyRewardScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.Gameplay.route,
            arguments = listOf(navArgument(Screen.Gameplay.ARG_LEVEL_NUMBER) { type = NavType.IntType })
        ) { backStackEntry ->
            val levelNumber = backStackEntry.arguments?.getInt(Screen.Gameplay.ARG_LEVEL_NUMBER) ?: 1
            GameplayScreen(
                levelNumber = levelNumber,
                onBack = { navController.popBackStack() },
                onLevelComplete = { score, stars, coins ->
                    navController.navigate(Screen.LevelComplete.createRoute(levelNumber, score, stars, coins)) {
                        popUpTo(Screen.Home.route)
                    }
                },
                onGameOver = { score ->
                    navController.navigate(Screen.GameOver.createRoute(levelNumber, score)) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }

        composable(
            route = Screen.LevelComplete.route,
            arguments = listOf(
                navArgument(Screen.LevelComplete.ARG_LEVEL_NUMBER) { type = NavType.IntType },
                navArgument(Screen.LevelComplete.ARG_SCORE) { type = NavType.IntType },
                navArgument(Screen.LevelComplete.ARG_STARS) { type = NavType.IntType },
                navArgument(Screen.LevelComplete.ARG_COINS) { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val args = backStackEntry.arguments
            val levelNumber = args?.getInt(Screen.LevelComplete.ARG_LEVEL_NUMBER) ?: 1
            LevelCompleteScreen(
                levelNumber = levelNumber,
                score = args?.getInt(Screen.LevelComplete.ARG_SCORE) ?: 0,
                stars = args?.getInt(Screen.LevelComplete.ARG_STARS) ?: 0,
                coinsEarned = args?.getInt(Screen.LevelComplete.ARG_COINS) ?: 0,
                onHome = { navController.popBackStack(Screen.Home.route, inclusive = false) },
                onRetry = {
                    navController.navigate(Screen.Gameplay.createRoute(levelNumber)) {
                        popUpTo(Screen.Home.route)
                    }
                },
                onNextLevel = {
                    navController.navigate(Screen.Gameplay.createRoute(levelNumber + 1)) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }

        composable(
            route = Screen.GameOver.route,
            arguments = listOf(
                navArgument(Screen.GameOver.ARG_LEVEL_NUMBER) { type = NavType.IntType },
                navArgument(Screen.GameOver.ARG_SCORE) { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val args = backStackEntry.arguments
            val levelNumber = args?.getInt(Screen.GameOver.ARG_LEVEL_NUMBER) ?: 1
            GameOverScreen(
                levelNumber = levelNumber,
                score = args?.getInt(Screen.GameOver.ARG_SCORE) ?: 0,
                onHome = { navController.popBackStack(Screen.Home.route, inclusive = false) },
                onRetry = {
                    navController.navigate(Screen.Gameplay.createRoute(levelNumber)) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }
    }
}
