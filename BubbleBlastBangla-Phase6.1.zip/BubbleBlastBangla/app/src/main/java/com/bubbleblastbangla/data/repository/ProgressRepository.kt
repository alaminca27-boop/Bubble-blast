package com.bubbleblastbangla.data.repository

import com.bubbleblastbangla.data.models.DailyRewardCatalog
import com.bubbleblastbangla.data.models.PlayerProgress
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.data.persistence.SaveManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Result of one claim attempt (spec section 13) — the UI shows this directly rather than re-deriving it from progress. */
data class DailyRewardClaimResult(
    val claimed: Boolean,
    val coinsAwarded: Int,
    val dayClaimed: Int,
    val alreadyClaimedToday: Boolean,
    val bonusPowerUp: PowerUpType? = null
)

/**
 * Single source of truth for player state while the app is running. Loads
 * once from [SaveManager] at startup, keeps an in-memory [StateFlow] the UI
 * observes reactively, and writes through to disk on every change — so
 * memory and disk never drift apart (Phase 1 architecture doc, "Offline
 * Save System").
 */
class ProgressRepository(private val saveManager: SaveManager, private val scope: CoroutineScope) {

    private val _progress = MutableStateFlow(PlayerProgress())
    val progress: StateFlow<PlayerProgress> = _progress

    init {
        scope.launch {
            _progress.value = saveManager.progressFlow.first()
            // Credit any hearts earned while the app was closed (spec section
            // 14: "If the app is closed and reopened, calculate elapsed time
            // and restore appropriate hearts") — done once up front so the
            // very first frame already shows the correct heart count.
            refreshHeartRegen()
        }
    }

    private fun update(transform: (PlayerProgress) -> PlayerProgress) {
        val updated = transform(_progress.value)
        _progress.value = updated
        scope.launch { saveManager.save(updated) }
    }

    /** Returns true if the spend succeeded (spec section 11: "Check balance before purchases"). */
    fun spendCoins(amount: Int): Boolean {
        if (_progress.value.coins < amount) return false
        update { it.copy(coins = it.coins - amount) }
        return true
    }

    fun addCoins(amount: Int) {
        update { it.copy(coins = it.coins + amount) }
    }

    fun loseHeart() {
        update {
            val newHearts = (it.hearts - 1).coerceAtLeast(0)
            // Start the regen countdown the moment hearts first drop below max; don't restart it on every subsequent loss.
            val regenStart = it.heartRegenStartEpochMillis ?: if (newHearts < it.maxHearts) System.currentTimeMillis() else null
            it.copy(hearts = newHearts, heartRegenStartEpochMillis = regenStart)
        }
    }

    /**
     * Heart regeneration (spec section 14): one heart every [HEART_REGEN_INTERVAL_MILLIS]
     * of real elapsed time, computed from a saved timestamp rather than a
     * running timer — so it works correctly whether the app was open,
     * backgrounded, or fully closed and reopened, entirely offline. Safe to
     * call as often as convenient (e.g. on screen entry); it's a no-op
     * once hearts are already full.
     */
    fun refreshHeartRegen(nowEpochMillis: Long = System.currentTimeMillis()) {
        val current = _progress.value
        if (current.hearts >= current.maxHearts) {
            if (current.heartRegenStartEpochMillis != null) update { it.copy(heartRegenStartEpochMillis = null) }
            return
        }

        val start = current.heartRegenStartEpochMillis ?: nowEpochMillis
        val elapsed = (nowEpochMillis - start).coerceAtLeast(0)
        if (elapsed < HEART_REGEN_INTERVAL_MILLIS) {
            if (current.heartRegenStartEpochMillis == null) update { it.copy(heartRegenStartEpochMillis = start) }
            return
        }

        val heartsGained = (elapsed / HEART_REGEN_INTERVAL_MILLIS).toInt()
        val newHearts = (current.hearts + heartsGained).coerceAtMost(current.maxHearts)
        val remainderMillis = elapsed % HEART_REGEN_INTERVAL_MILLIS
        // Carry over partial progress toward the *next* heart, unless we're already full.
        val newRegenStart = if (newHearts >= current.maxHearts) null else nowEpochMillis - remainderMillis
        update { it.copy(hearts = newHearts, heartRegenStartEpochMillis = newRegenStart) }
    }

    /** Records a level result: unlocks the next level, keeps the best star rating and best score (spec section 8: "Save the highest star rating achieved"). */
    fun recordLevelResult(levelNumber: Int, starsEarned: Int, scoreEarned: Int, coinsEarned: Int) {
        update { current ->
            val bestStars = maxOf(current.starsPerLevel[levelNumber] ?: 0, starsEarned)
            val bestScore = maxOf(current.bestScorePerLevel[levelNumber] ?: 0, scoreEarned)
            val newUnlocked = maxOf(current.highestUnlockedLevel, levelNumber + 1)
            current.copy(
                coins = current.coins + coinsEarned,
                highestUnlockedLevel = newUnlocked,
                starsPerLevel = current.starsPerLevel + (levelNumber to bestStars),
                bestScorePerLevel = current.bestScorePerLevel + (levelNumber to bestScore)
            )
        }
    }

    fun purchasePowerUp(type: PowerUpType): Boolean {
        if (!spendCoins(type.coinCost)) return false
        update { it.copy(powerUpInventory = it.powerUpInventory + (type to (it.powerUpInventory[type] ?: 0) + 1)) }
        return true
    }

    /** Returns true if a unit was available and consumed. */
    fun consumePowerUp(type: PowerUpType): Boolean {
        val available = _progress.value.powerUpInventory[type] ?: 0
        if (available <= 0) return false
        update { it.copy(powerUpInventory = it.powerUpInventory + (type to available - 1)) }
        return true
    }

    fun setSettings(musicOn: Boolean = _progress.value.musicOn, soundOn: Boolean = _progress.value.soundOn, vibrationOn: Boolean = _progress.value.vibrationOn) {
        update { it.copy(musicOn = musicOn, soundOn = soundOn, vibrationOn = vibrationOn) }
    }

    fun purchaseTheme(themeId: String, price: Int): Boolean {
        if (_progress.value.ownedThemes.contains(themeId)) return false // already owned, nothing to buy
        if (!spendCoins(price)) return false
        update { it.copy(ownedThemes = it.ownedThemes + themeId) }
        return true
    }

    fun selectTheme(themeId: String) {
        if (!_progress.value.ownedThemes.contains(themeId)) return // must own it first
        update { it.copy(selectedTheme = themeId) }
    }

    fun purchaseBubbleSkin(skinId: String, price: Int): Boolean {
        if (_progress.value.ownedBubbleSkins.contains(skinId)) return false
        if (!spendCoins(price)) return false
        update { it.copy(ownedBubbleSkins = it.ownedBubbleSkins + skinId) }
        return true
    }

    fun selectBubbleSkin(skinId: String) {
        if (!_progress.value.ownedBubbleSkins.contains(skinId)) return
        update { it.copy(selectedBubbleSkin = skinId) }
    }

    /**
     * Attempts to claim today's daily reward (spec section 13).
     *
     * Offline-safe date handling: uses the device's local epoch-day number
     * (days since 1970-01-01) rather than elapsed real time, so it can't be
     * gamed by leaving the app open, and doesn't need server time. Three
     * cases:
     *  - Same epoch day as the last claim -> already claimed today, refuse.
     *  - Exactly one day later -> the streak continues, day advances
     *    (wrapping 7 back to 1).
     *  - More than one day later (a missed day, or the clock jumped
     *    forward/back) -> the streak simply restarts at day 1 rather than
     *    penalizing the player further or trying to "back-fill" missed
     *    days offline. This is the documented, intentionally simple
     *    behavior for the offline-only case described in spec section 13.
     */
    fun claimDailyReward(todayEpochDay: Long): DailyRewardClaimResult {
        val current = _progress.value
        if (current.dailyRewardLastClaimEpochDay == todayEpochDay) {
            return DailyRewardClaimResult(claimed = false, coinsAwarded = 0, dayClaimed = current.dailyRewardDay, alreadyClaimedToday = true)
        }

        val isConsecutive = current.dailyRewardLastClaimEpochDay?.let { it == todayEpochDay - 1 } ?: false
        val dayToClaim = if (isConsecutive) current.dailyRewardDay else 1
        val coins = DailyRewardCatalog.coinsForDay(dayToClaim)
        val nextDay = if (dayToClaim >= 7) 1 else dayToClaim + 1
        // Day 7's "+ bonus" (spec section 13 / Phase 5.1 item 2) is a real,
        // granted-once-per-claim power-up, applied in the same atomic
        // update as the coins so there's no window where one could persist
        // without the other.
        val bonusPowerUp = if (DailyRewardCatalog.isBonusDay(dayToClaim)) DAY_7_BONUS_POWER_UP else null

        update {
            val newInventory = if (bonusPowerUp != null) {
                it.powerUpInventory + (bonusPowerUp to (it.powerUpInventory[bonusPowerUp] ?: 0) + 1)
            } else {
                it.powerUpInventory
            }
            it.copy(
                coins = it.coins + coins,
                dailyRewardDay = nextDay,
                dailyRewardLastClaimEpochDay = todayEpochDay,
                powerUpInventory = newInventory
            )
        }
        return DailyRewardClaimResult(
            claimed = true,
            coinsAwarded = coins,
            dayClaimed = dayToClaim,
            alreadyClaimedToday = false,
            bonusPowerUp = bonusPowerUp
        )
    }

    fun resetProgress() {
        scope.launch {
            saveManager.resetAll()
            _progress.value = PlayerProgress()
        }
    }

    companion object {
        /** One heart every 5 minutes — a casual-game-standard pace that's meaningful but not "unnecessarily slow" (Phase 5.1 item 4). */
        private const val HEART_REGEN_INTERVAL_MILLIS = 5 * 60 * 1000L
        /** Day 7's real bonus item (spec section 13 / Phase 5.1 item 2): one free Bomb power-up on top of the coins. */
        val DAY_7_BONUS_POWER_UP = PowerUpType.BOMB
    }
}
