package com.bubbleblastbangla.ui.gameplay

import com.bubbleblastbangla.data.models.PowerUpType

/**
 * Hook points for sound effects and "juicy" animations tied to real
 * gameplay events (spec section 6: "Add proper visual feedback / animation
 * hooks / sound-effect hooks"; spec section 18 lists the actual sound
 * effects). Every method is a no-op by default via the interface's default
 * bodies, and [NoOp] is the instance [GameplayViewModel] uses today.
 *
 * This is deliberately just the hook contract, not a sound/animation
 * engine — wiring SoundPool/MediaPlayer and real particle effects is
 * Phase 6 ("Sound, Animation, Ads architecture, Performance"). When that
 * phase lands, a real `SoundManager`-backed implementation gets passed into
 * [GameplayViewModel.audioHooks] and every call site below starts doing
 * something audible/visible — no call site changes needed.
 */
interface GameplayAudioHooks {
    fun onShotFired() {}
    fun onBubblesMatched(count: Int) {}
    fun onBubblesFell(count: Int) {}
    fun onPowerUpUsed(type: PowerUpType) {}
    fun onPowerUpPurchased(type: PowerUpType) {}
    fun onLevelCleared() {}
    fun onLevelFailed() {}

    companion object NoOp : GameplayAudioHooks
}
