package com.bubbleblastbangla.game.matching

import com.bubbleblastbangla.game.board.BubbleGrid
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath

/**
 * Finds bubbles that are no longer connected (directly or transitively) to
 * the ceiling row after a match is removed (spec section 5: "Unsupported
 * bubbles should fall"). Every occupied cell in row 0 is a root; anything
 * reachable from a root through same-grid neighbors (any color, since
 * physical support doesn't care about color) stays up. Everything else
 * falls.
 */
object FallDetector {

    fun findFloatingCells(grid: BubbleGrid, gridMath: GridMath): Set<CellCoord> {
        val occupied = grid.occupiedCells()
        val roots = occupied.filter { it.row == 0 }
        if (roots.isEmpty()) return occupied // nothing anchored to the ceiling — everything falls

        val connected = mutableSetOf<CellCoord>()
        val queue = ArrayDeque<CellCoord>().apply { addAll(roots) }
        connected.addAll(roots)

        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            for (neighbor in gridMath.neighborsOf(current)) {
                if (neighbor in connected) continue
                if (!grid.isOccupied(neighbor)) continue
                connected += neighbor
                queue += neighbor
            }
        }

        return occupied - connected
    }
}
