package com.bubbleblastbangla.ui.gameplay

import androidx.compose.ui.graphics.Color
import com.bubbleblastbangla.game.model.BubbleColor
import com.bubbleblastbangla.ui.theme.BubbleBlueGame
import com.bubbleblastbangla.ui.theme.BubbleGreenGame
import com.bubbleblastbangla.ui.theme.BubblePurpleGame
import com.bubbleblastbangla.ui.theme.BubbleRed
import com.bubbleblastbangla.ui.theme.BubbleYellowGame

/** The single place that converts the engine's renderer-agnostic [BubbleColor] into a drawable Compose [Color]. */
fun BubbleColor.toComposeColor(): Color = when (this) {
    BubbleColor.RED -> BubbleRed
    BubbleColor.BLUE -> BubbleBlueGame
    BubbleColor.GREEN -> BubbleGreenGame
    BubbleColor.YELLOW -> BubbleYellowGame
    BubbleColor.PURPLE -> BubblePurpleGame
}
