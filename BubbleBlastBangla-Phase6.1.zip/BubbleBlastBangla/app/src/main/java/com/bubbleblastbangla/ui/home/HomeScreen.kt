package com.bubbleblastbangla.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.data.models.ThemeCatalog
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.CoinCounter
import com.bubbleblastbangla.ui.components.HeartCounter
import com.bubbleblastbangla.ui.components.PandaMascot
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubbleBlue
import com.bubbleblastbangla.ui.theme.BubbleGreen
import com.bubbleblastbangla.ui.theme.BubbleOrange
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.BubbleYellow

/**
 * Screen 1 — HOME (spec section 3).
 *
 * Coins/hearts now come from the real, persisted [com.bubbleblastbangla.data.repository.ProgressRepository]
 * (Phase 4) instead of Phase 2/3's in-memory placeholder. The background
 * gradient now reflects the player's selected Shop theme (Phase 5) instead
 * of a hardcoded forest gradient.
 */
@Composable
fun HomeScreen(
    onPlayClick: () -> Unit,
    onLevelMapClick: () -> Unit,
    onShopClick: () -> Unit,
    onDailyRewardClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onTutorialClick: () -> Unit
) {
    val repository = rememberProgressRepository()
    val progress by repository.progress.collectAsState()
    val themeColors = ThemeCatalog.colorsFor(progress.selectedTheme)
    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as com.bubbleblastbangla.app.BubbleBlastApplication

    LaunchedEffect(Unit) { app.audio.playMusic(com.bubbleblastbangla.audio.MusicTrack.HOME) }

    // Heart regeneration (spec section 14) is computed from a saved
    // timestamp, not a running timer — this loop just re-checks it
    // periodically so the counter visibly ticks up while the player is
    // sitting on Home, without needing a background service.
    LaunchedEffect(Unit) {
        while (true) {
            repository.refreshHeartRegen()
            kotlinx.coroutines.delay(30_000)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = themeColors))
    ) {
        // Top bar: coin + heart counters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CoinCounter(coins = progress.coins)
            HeartCounter(hearts = progress.hearts)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp, vertical = 24.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            // Logo
            Text(
                text = "BUBBLE BLAST",
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "BANGLA",
                style = MaterialTheme.typography.headlineMedium,
                color = BubbleYellow,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            PandaMascot(size = 140.dp, modifier = Modifier.size(140.dp))

            Spacer(modifier = Modifier.height(28.dp))

            RoundedGameButton(text = "PLAY", baseColor = BubbleGreen, onClick = onPlayClick)
            Spacer(modifier = Modifier.height(14.dp))
            RoundedGameButton(text = "LEVEL MAP", baseColor = BubblePurple, onClick = onLevelMapClick)
            Spacer(modifier = Modifier.height(14.dp))
            RoundedGameButton(text = "SHOP", baseColor = BubbleBlue, onClick = onShopClick)
            Spacer(modifier = Modifier.height(14.dp))
            RoundedGameButton(text = "DAILY REWARD", baseColor = BubbleOrange, onClick = onDailyRewardClick)
            Spacer(modifier = Modifier.height(14.dp))
            RoundedGameButton(text = "SETTINGS", baseColor = BubbleYellow, onClick = onSettingsClick)
            Spacer(modifier = Modifier.height(14.dp))
            RoundedGameButton(text = "HOW TO PLAY", baseColor = BubblePurple, onClick = onTutorialClick)
        }
    }
}
