package com.bubbleblastbangla.data.models

import com.bubbleblastbangla.game.model.BubbleColor

/**
 * Score needed for 2 and 3 stars (spec section 8). 1 star is always just
 * "complete the level" — no threshold needed for it.
 */
data class StarThresholds(
    val twoStarScore: Int,
    val threeStarScore: Int
)

/** One playable level's full definition (spec section 7). Loaded from [com.bubbleblastbangla.data.level.LevelRepository] — never hardcoded into gameplay code. */
data class LevelConfig(
    val levelNumber: Int,
    val filledRows: Int,
    val colorCount: Int,
    val shotLimit: Int,
    val targetType: TargetType,
    val targetValue: Int,
    val coinReward: Int,
    val starThresholds: StarThresholds,
    val obstacleCells: Set<Pair<Int, Int>> = emptySet() // (row, col) cells that are pre-blocked — reserved for future obstacle mechanics
) {
    val palette: List<BubbleColor> get() = BubbleColor.entries.take(colorCount)
}
