package com.bubbleblastbangla.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable

/**
 * Large, rounded, glossy-highlight button used across Home/Level Map/Shop for
 * primary actions (PLAY, LEVEL MAP, SHOP, DAILY REWARD, SETTINGS).
 *
 * The "glossy bubble" look (spec section 1 & 20) comes from a vertical
 * gradient (lighter at top) plus a soft drop shadow, without needing an
 * image asset — this keeps buttons themeable purely through [baseColor].
 *
 * Phase 6 additions (items 2 & 8): a light press-scale animation, a
 * built-in tap debounce (ignores a second tap within [debounceMillis] of
 * the first) so rapid double-tapping can't fire BUY/CLAIM/PLAY/etc twice,
 * and — via [LocalGameFeedback] — a standard button-press sound + haptic on
 * every tap without every call site wiring it up individually.
 */
@Composable
fun RoundedGameButton(
    text: String,
    baseColor: Color,
    modifier: Modifier = Modifier,
    height: Dp = 64.dp,
    icon: ImageVector? = null,
    debounceMillis: Long = 400L,
    onClick: () -> Unit
) {
    val gradient = Brush.verticalGradient(
        colors = listOf(baseColor.lighten(0.18f), baseColor)
    )
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(targetValue = if (isPressed) 0.96f else 1f, animationSpec = tween(80), label = "buttonPressScale")
    val feedback = LocalGameFeedback.current
    var lastClickAtMillis by remember { androidx.compose.runtime.mutableStateOf(0L) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .scale(scale)
            .clip(RoundedCornerShape(height / 2)),
        shadowElevation = 6.dp,
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .background(gradient, RoundedCornerShape(height / 2))
                .clickable(interactionSource = interactionSource, indication = null) {
                    val now = System.currentTimeMillis()
                    if (now - lastClickAtMillis < debounceMillis) return@clickable // swallow accidental double-tap
                    lastClickAtMillis = now
                    feedback.onButtonPress()
                    onClick()
                }
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, tint = Color.White)
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                color = Color.White
            )
        }
    }
}

private fun Color.lighten(fraction: Float): Color {
    return Color(
        red = (red + (1f - red) * fraction).coerceIn(0f, 1f),
        green = (green + (1f - green) * fraction).coerceIn(0f, 1f),
        blue = (blue + (1f - blue) * fraction).coerceIn(0f, 1f),
        alpha = alpha
    )
}
