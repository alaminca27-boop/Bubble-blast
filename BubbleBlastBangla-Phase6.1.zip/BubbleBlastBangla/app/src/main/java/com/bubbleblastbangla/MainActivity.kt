package com.bubbleblastbangla

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.bubbleblastbangla.app.BubbleBlastApplication
import com.bubbleblastbangla.navigation.BubbleBlastNavGraph
import com.bubbleblastbangla.ui.components.LocalGameFeedback
import com.bubbleblastbangla.ui.components.RealGameFeedback
import com.bubbleblastbangla.ui.theme.BubbleBlastBanglaTheme

/**
 * Single-activity host. All screens are Composable destinations reached
 * through [BubbleBlastNavGraph] — see navigation/NavGraph.kt.
 *
 * Phase 6: provides [LocalGameFeedback] once here (backed by the real
 * Application-level audio/haptics singletons) so every RoundedGameButton
 * anywhere in the tree gets a standard press sound + haptic for free.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as BubbleBlastApplication
        setContent {
            val feedback = remember { RealGameFeedback(app.audio, app.haptics) }
            CompositionLocalProvider(LocalGameFeedback provides feedback) {
                BubbleBlastBanglaTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        BubbleBlastNavGraph()
                    }
                }
            }
        }
    }
}
