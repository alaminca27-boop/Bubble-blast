package com.bubbleblastbangla.game.powerups

import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.game.board.BubbleGrid
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath

/** Cells a power-up destroys directly (before any falling is resolved). */
data class PowerUpImpact(val destroyedCells: Set<CellCoord>)

/**
 * Implements the four power-ups from spec section 6. Each effect is applied
 * to a player-chosen target cell rather than the shot trajectory, since the
 * player taps the board to aim a power-up (see GameplayViewModel).
 *
 * SIMPLIFICATION NOTE (Phase 4 scope, per spec section 27 — "if something
 * cannot be implemented exactly as requested, explain the limitation and
 * give the closest working implementation"): the spec describes Rainbow as
 * a shooter-bubble wildcard ("can match with any bubble color"), which
 * would require plumbing a per-shot wildcard flag through the shooter and
 * trajectory/landing code. To keep this phase's power-up system simple,
 * consistent with the other three (tap a target, something is destroyed),
 * Rainbow is implemented here as an instant "clear every bubble of the
 * target's color on the board" effect instead — a different but comparably
 * powerful payoff for the same coin cost. Swapping in the true wildcard
 * behavior later only requires changing this one function.
 */
object PowerUpEffect {

    fun apply(type: PowerUpType, grid: BubbleGrid, gridMath: GridMath, target: CellCoord): PowerUpImpact {
        return when (type) {
            PowerUpType.BOMB -> bomb(grid, gridMath, target)
            PowerUpType.LIGHTNING -> lightning(grid, target)
            PowerUpType.RAINBOW -> rainbow(grid, target)
            PowerUpType.FIREBALL -> fireball(grid, target)
        }
    }

    /** Destroys the target bubble and its immediate neighbors. */
    private fun bomb(grid: BubbleGrid, gridMath: GridMath, target: CellCoord): PowerUpImpact {
        val cells = (gridMath.neighborsOf(target) + target)
            .filter { grid.isOccupied(it) }
            .toSet()
        return PowerUpImpact(cells)
    }

    /** Clears the entire row the target cell is in. */
    private fun lightning(grid: BubbleGrid, target: CellCoord): PowerUpImpact {
        val cells = grid.occupiedCells().filter { it.row == target.row }.toSet()
        return PowerUpImpact(cells)
    }

    /** Clears every bubble on the board sharing the target's color (see class doc). */
    private fun rainbow(grid: BubbleGrid, target: CellCoord): PowerUpImpact {
        val color = grid.colorAt(target) ?: return PowerUpImpact(emptySet())
        val cells = grid.occupiedCells().filter { grid.colorAt(it) == color }.toSet()
        return PowerUpImpact(cells)
    }

    /** Punches straight through the target's column, destroying every bubble in its path. */
    private fun fireball(grid: BubbleGrid, target: CellCoord): PowerUpImpact {
        val cells = grid.occupiedCells().filter { it.col == target.col }.toSet()
        return PowerUpImpact(cells)
    }
}
