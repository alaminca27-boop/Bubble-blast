package com.bubbleblastbangla.game.shooter

import com.bubbleblastbangla.game.board.BubbleGrid
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath
import com.bubbleblastbangla.game.util.PointF
import kotlin.math.cos
import kotlin.math.sin

data class TrajectoryResult(
    val path: List<PointF>,
    val landingCell: CellCoord
)

/**
 * Simulates a fired bubble's path: a straight line that bounces off the left
 * and right board walls (mirroring the x velocity, per spec section 8), and
 * stops the instant it would overlap an existing bubble or reach the
 * ceiling row. This is a deliberately simple step-wise simulation rather
 * than exact analytic geometry — it is easy to reason about, cheap at this
 * board size, and standard practice for casual bubble shooters (spec
 * section 5: "Do not make the physics unnecessarily complicated").
 */
object TrajectoryCalculator {

    private const val STEP_FRACTION_OF_RADIUS = 0.25f
    private const val MAX_STEPS = 4000

    /**
     * @param start shooter position (bottom-center of the board, in px)
     * @param angleFromVerticalRadians 0 = straight up; positive = tilted right
     */
    fun simulate(
        start: PointF,
        angleFromVerticalRadians: Float,
        boardWidthPx: Float,
        grid: BubbleGrid,
        gridMath: GridMath
    ): TrajectoryResult {
        val radius = gridMath.radius
        val step = radius * STEP_FRACTION_OF_RADIUS

        var vx = sin(angleFromVerticalRadians) * step
        var vy = -cos(angleFromVerticalRadians) * step // negative y = up

        var x = start.x
        var y = start.y

        val path = mutableListOf(PointF(x, y))
        val occupied = grid.occupiedCells()

        repeat(MAX_STEPS) {
            x += vx
            y += vy

            // Bounce off side walls.
            if (x - radius < 0f) {
                x = radius
                vx = -vx
            } else if (x + radius > boardWidthPx) {
                x = boardWidthPx - radius
                vx = -vx
            }

            path += PointF(x, y)

            // Hit the ceiling with nothing in the way — lands in row 0.
            if (y - radius <= 0f) {
                val landing = gridMath.nearestCell(PointF(x, radius), grid.rows - 1)
                return TrajectoryResult(path, resolveOpenCell(landing, grid, gridMath))
            }

            // Collision against any existing bubble.
            val current = PointF(x, y)
            for (cell in occupied) {
                val center = gridMath.cellCenter(cell)
                if (current.distanceTo(center) < gridMath.diameter * 0.96f) {
                    // Snap to the nearest empty neighbor of the bubble we hit.
                    val candidateNeighbors = gridMath.neighborsOf(cell)
                        .filter { grid.isInBounds(it) && !grid.isOccupied(it) }
                    val landing = candidateNeighbors.minByOrNull { gridMath.cellCenter(it).distanceTo(current) }
                        ?: gridMath.nearestCell(current, grid.rows - 1)
                    return TrajectoryResult(path, landing)
                }
            }
        }

        // Safety fallback (should not normally happen): snap wherever we ended up.
        val fallback = gridMath.nearestCell(PointF(x, y), grid.rows - 1)
        return TrajectoryResult(path, resolveOpenCell(fallback, grid, gridMath))
    }

    /** If the naive nearest cell happens to already be occupied, walk outward to the closest free one. */
    private fun resolveOpenCell(cell: CellCoord, grid: BubbleGrid, gridMath: GridMath): CellCoord {
        if (!grid.isOccupied(cell) && grid.isInBounds(cell)) return cell
        val target = gridMath.cellCenter(cell)
        var best: CellCoord? = null
        var bestDist = Float.MAX_VALUE
        for (row in 0 until grid.rows) {
            for (col in 0 until grid.cols) {
                val candidate = CellCoord(row, col)
                if (grid.isOccupied(candidate)) continue
                val dist = gridMath.cellCenter(candidate).distanceTo(target)
                if (dist < bestDist) {
                    bestDist = dist
                    best = candidate
                }
            }
        }
        return best ?: cell
    }
}
