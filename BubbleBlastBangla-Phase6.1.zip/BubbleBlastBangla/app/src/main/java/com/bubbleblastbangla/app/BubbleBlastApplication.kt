package com.bubbleblastbangla.app

import android.app.Application
import com.bubbleblastbangla.ads.AdProvider
import com.bubbleblastbangla.ads.NoOpAdProvider
import com.bubbleblastbangla.audio.GameAudioController
import com.bubbleblastbangla.data.persistence.SaveManager
import com.bubbleblastbangla.data.repository.ProgressRepository
import com.bubbleblastbangla.haptics.HapticManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Application entry point. Constructs the small set of app-wide singletons
 * here instead of using a DI framework (Hilt/Koin) — the project is small
 * enough that a manual container stays easy to follow (Phase 1 architecture
 * doc). Phase 6 adds [audio], [haptics], and [adProvider] alongside the
 * existing save/progress singletons — same pattern, no new architecture.
 *
 * [applicationScope] outlives any single screen, which is what we want for
 * "write the save to disk" work started from a ViewModel that might be
 * cleared mid-write (e.g. rapid back-navigation right after a purchase).
 */
class BubbleBlastApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var saveManager: SaveManager
        private set
    lateinit var progressRepository: ProgressRepository
        private set
    lateinit var audio: GameAudioController
        private set
    lateinit var haptics: HapticManager
        private set

    /** No real ad SDK is wired up (see AdProvider.kt) — swap this for a real implementation when one exists. */
    val adProvider: AdProvider = NoOpAdProvider

    override fun onCreate() {
        super.onCreate()
        saveManager = SaveManager(this)
        progressRepository = ProgressRepository(saveManager, applicationScope)
        audio = GameAudioController(this, progressRepository)
        haptics = HapticManager(this, progressRepository)
    }

    override fun onTerminate() {
        super.onTerminate()
        audio.release() // best-effort — onTerminate is not guaranteed to run on real devices, but this is harmless either way
    }
}
