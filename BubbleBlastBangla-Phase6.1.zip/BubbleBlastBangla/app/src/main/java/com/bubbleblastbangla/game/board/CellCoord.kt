package com.bubbleblastbangla.game.board

/** A single cell address in the offset bubble grid. Row 0 is the ceiling row. */
data class CellCoord(val row: Int, val col: Int)
