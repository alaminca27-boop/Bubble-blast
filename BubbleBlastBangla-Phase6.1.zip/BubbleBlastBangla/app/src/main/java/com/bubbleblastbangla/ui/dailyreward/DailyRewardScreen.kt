package com.bubbleblastbangla.ui.dailyreward

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.data.models.DailyRewardCatalog
import com.bubbleblastbangla.data.repository.DailyRewardClaimResult
import com.bubbleblastbangla.data.repository.ProgressRepository
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BackgroundForestBottom
import com.bubbleblastbangla.ui.theme.BackgroundForestTop
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.CoinGold
import com.bubbleblastbangla.ui.theme.LockedGray
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.TextPrimary
import java.time.LocalDate
import java.time.ZoneId

/**
 * Daily Reward screen (spec section 13). Claim eligibility and streak
 * advancement are entirely decided by ProgressRepository.claimDailyReward
 * (device-local epoch day, offline-safe — see its doc comment for the
 * missed-day rule) — this screen only displays state and calls it once per
 * tap, so it can't grant a reward twice no matter how the screen is
 * reopened.
 */
@Composable
fun DailyRewardScreen(onBack: () -> Unit) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    var lastResult by remember { mutableStateOf<DailyRewardClaimResult?>(null) }

    val todayEpochDay = remember { LocalDate.now(ZoneId.systemDefault()).toEpochDay() }
    val alreadyClaimedToday = progress.dailyRewardLastClaimEpochDay == todayEpochDay
    val currentDay = progress.dailyRewardDay

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = listOf(BackgroundForestTop, BackgroundForestBottom)))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundedGameButton(text = "BACK", baseColor = BubblePurple, modifier = Modifier.width(100.dp), height = 44.dp, onClick = onBack)
            Text(text = "DAILY REWARD", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.ExtraBold)
            com.bubbleblastbangla.ui.components.PandaMascot(
                size = 44.dp,
                modifier = Modifier.size(44.dp),
                mood = com.bubbleblastbangla.ui.components.PandaMood.EXCITED
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items((1..7).toList()) { day ->
                val claimed = day < currentDay || (day == currentDay && alreadyClaimedToday)
                val available = day == currentDay && !alreadyClaimedToday
                DayCard(
                    day = day,
                    coins = DailyRewardCatalog.coinsForDay(day),
                    bonus = DailyRewardCatalog.isBonusDay(day),
                    bonusLabel = if (DailyRewardCatalog.isBonusDay(day)) "+1 ${ProgressRepository.DAY_7_BONUS_POWER_UP.displayName}" else null,
                    claimed = claimed,
                    available = available
                )
            }
        }

        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(20.dp))

        lastResult?.let { result ->
            val bonusText = result.bonusPowerUp?.let { " + 1 ${it.displayName}!" } ?: ""
            Text(
                text = if (result.alreadyClaimedToday) "Already claimed today — come back tomorrow!" else "Day ${result.dayClaimed} reward: +${result.coinsAwarded} coins$bonusText",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(12.dp))
        }

        RoundedGameButton(
            text = if (alreadyClaimedToday) "COME BACK TOMORROW" else "CLAIM DAY $currentDay",
            baseColor = if (alreadyClaimedToday) LockedGray else CoinGold,
            onClick = {
                if (!alreadyClaimedToday) {
                    lastResult = progressRepository.claimDailyReward(todayEpochDay)
                }
            }
        )
    }
}

@Composable
private fun DayCard(day: Int, coins: Int, bonus: Boolean, bonusLabel: String?, claimed: Boolean, available: Boolean) {
    val bg = when {
        claimed -> LockedGray
        available -> CoinGold
        else -> SurfaceCard
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Day $day", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        Text(text = "$coins\uD83D\uDCB0", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        if (bonus && bonusLabel != null) Text(text = bonusLabel, style = MaterialTheme.typography.bodyLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Text(
            text = if (claimed) "\u2714" else if (available) "!" else "",
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
    }
}
