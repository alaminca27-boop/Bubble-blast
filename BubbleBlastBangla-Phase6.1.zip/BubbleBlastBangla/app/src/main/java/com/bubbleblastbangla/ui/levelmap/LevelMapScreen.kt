package com.bubbleblastbangla.ui.levelmap

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.data.models.ThemeCatalog
import com.bubbleblastbangla.data.level.LevelRepository
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.CoinCounter
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BubblePurple
import com.bubbleblastbangla.ui.theme.BubbleYellow
import com.bubbleblastbangla.ui.theme.LockedGray
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.TextPrimary

/**
 * Screen 2 — LEVEL MAP (spec section 3). Every level 1..100 comes from
 * [LevelRepository]; unlock/star state comes from the real, persisted
 * player progress (spec section 8: "Save the highest star rating achieved").
 * Level 1 starts unlocked; completing a level unlocks the next, exactly as
 * spec section 3 describes.
 */
@Composable
fun LevelMapScreen(onBack: () -> Unit, onLevelClick: (Int) -> Unit) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as com.bubbleblastbangla.app.BubbleBlastApplication
    androidx.compose.runtime.LaunchedEffect(Unit) { app.audio.playMusic(com.bubbleblastbangla.audio.MusicTrack.LEVEL_MAP) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = ThemeCatalog.colorsFor(progress.selectedTheme)))
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundedGameButton(
                    text = "BACK",
                    baseColor = BubblePurple,
                    modifier = Modifier.width(100.dp),
                    onClick = onBack
                )
                Text(
                    text = "LEVEL MAP",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
                CoinCounter(coins = progress.coins)
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(LevelRepository.allLevelNumbers()) { levelNumber ->
                    val unlocked = levelNumber <= progress.highestUnlockedLevel
                    val stars = progress.starsPerLevel[levelNumber] ?: 0
                    val isCurrent = levelNumber == progress.highestUnlockedLevel
                    LevelNode(
                        levelNumber = levelNumber,
                        unlocked = unlocked,
                        stars = stars,
                        isCurrent = isCurrent,
                        onClick = { if (unlocked) onLevelClick(levelNumber) }
                    )
                }
            }
        }
    }
}

@Composable
private fun LevelNode(levelNumber: Int, unlocked: Boolean, stars: Int, isCurrent: Boolean, onClick: () -> Unit) {
    val bg = if (unlocked) SurfaceCard else LockedGray
    val borderColor = if (isCurrent) BubblePurple else Color.Transparent
    Column(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(CircleShape)
            .then(
                if (isCurrent) Modifier.border(3.dp, borderColor, CircleShape) else Modifier
            )
            .background(bg)
            .clickable(enabled = unlocked, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (unlocked) levelNumber.toString() else "\uD83D\uDD12", // lock emoji for locked nodes
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        if (unlocked && stars > 0) {
            Row {
                repeat(3) { i ->
                    Text(
                        text = "\u2605", // filled star glyph
                        color = if (i < stars) BubbleYellow else LockedGray,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}
