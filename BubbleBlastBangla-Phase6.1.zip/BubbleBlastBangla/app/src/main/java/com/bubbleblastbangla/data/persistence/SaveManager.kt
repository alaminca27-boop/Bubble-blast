package com.bubbleblastbangla.data.persistence

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bubbleblastbangla.data.models.PlayerProgress
import com.bubbleblastbangla.data.models.PowerUpType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "player_progress")

/**
 * The single facade the rest of the app uses for persistence (spec section
 * 15: "All important progress must be saved locally"). Everything reads
 * through DataStore Preferences with plain scalar/string-encoded values —
 * no Room database — which is a deliberate simplification from the Phase 1
 * architecture doc's original "DataStore + Room" plan: at this project's
 * data size (a handful of counters plus two small per-level maps), a single
 * Preferences store covers every requirement in spec section 15 without the
 * extra Room schema/DAO/migration machinery. If per-level history ever
 * needs querying (e.g. "levels completed this week"), swapping in Room for
 * just the per-level maps is a contained change — SaveManager is the only
 * class that would need to know.
 *
 * Maps are encoded as simple "key:value,key:value" strings since DataStore
 * Preferences has no native map type and Map<PowerUpType, Int> needs a
 * custom (de)serializer either way — this keeps that logic in one place
 * without pulling in kotlinx.serialization for something this small.
 */
class SaveManager(context: Context) {

    private val appContext = context.applicationContext
    private val ds get() = appContext.dataStore

    private object Keys {
        val COINS = intPreferencesKey("coins")
        val HEARTS = intPreferencesKey("hearts")
        val MAX_HEARTS = intPreferencesKey("max_hearts")
        val HIGHEST_UNLOCKED = intPreferencesKey("highest_unlocked_level")
        val STARS_PER_LEVEL = stringPreferencesKey("stars_per_level")
        val BEST_SCORE_PER_LEVEL = stringPreferencesKey("best_score_per_level")
        val POWER_UP_INVENTORY = stringPreferencesKey("power_up_inventory")
        val MUSIC_ON = booleanPreferencesKey("music_on")
        val SOUND_ON = booleanPreferencesKey("sound_on")
        val VIBRATION_ON = booleanPreferencesKey("vibration_on")
        val SELECTED_THEME = stringPreferencesKey("selected_theme")
        val SELECTED_SKIN = stringPreferencesKey("selected_bubble_skin")
        val OWNED_THEMES = stringPreferencesKey("owned_themes")
        val OWNED_SKINS = stringPreferencesKey("owned_bubble_skins")
        val DAILY_REWARD_DAY = intPreferencesKey("daily_reward_day")
        val DAILY_REWARD_LAST_CLAIM = longPreferencesKey("daily_reward_last_claim_epoch_day")
        val HEART_REGEN_START = longPreferencesKey("heart_regen_start_epoch_millis")
        val LANGUAGE = stringPreferencesKey("language")
    }

    val progressFlow: Flow<PlayerProgress> = ds.data.map { prefs ->
        val defaults = PlayerProgress()
        PlayerProgress(
            coins = prefs[Keys.COINS] ?: defaults.coins,
            hearts = prefs[Keys.HEARTS] ?: defaults.hearts,
            maxHearts = prefs[Keys.MAX_HEARTS] ?: defaults.maxHearts,
            highestUnlockedLevel = prefs[Keys.HIGHEST_UNLOCKED] ?: defaults.highestUnlockedLevel,
            starsPerLevel = decodeIntMap(prefs[Keys.STARS_PER_LEVEL]),
            bestScorePerLevel = decodeIntMap(prefs[Keys.BEST_SCORE_PER_LEVEL]),
            powerUpInventory = decodePowerUpMap(prefs[Keys.POWER_UP_INVENTORY]) ?: defaults.powerUpInventory,
            musicOn = prefs[Keys.MUSIC_ON] ?: defaults.musicOn,
            soundOn = prefs[Keys.SOUND_ON] ?: defaults.soundOn,
            vibrationOn = prefs[Keys.VIBRATION_ON] ?: defaults.vibrationOn,
            selectedTheme = prefs[Keys.SELECTED_THEME] ?: defaults.selectedTheme,
            selectedBubbleSkin = prefs[Keys.SELECTED_SKIN] ?: defaults.selectedBubbleSkin,
            ownedThemes = decodeStringSet(prefs[Keys.OWNED_THEMES]) ?: defaults.ownedThemes,
            ownedBubbleSkins = decodeStringSet(prefs[Keys.OWNED_SKINS]) ?: defaults.ownedBubbleSkins,
            dailyRewardDay = prefs[Keys.DAILY_REWARD_DAY] ?: defaults.dailyRewardDay,
            dailyRewardLastClaimEpochDay = prefs[Keys.DAILY_REWARD_LAST_CLAIM],
            heartRegenStartEpochMillis = prefs[Keys.HEART_REGEN_START],
            language = prefs[Keys.LANGUAGE] ?: defaults.language
        )
    }

    /** Overwrites every persisted field with [progress]. Always awaited before the caller reports success — spec section 11: "Save balance after transactions". */
    suspend fun save(progress: PlayerProgress) {
        ds.edit { prefs ->
            prefs[Keys.COINS] = progress.coins.coerceAtLeast(0) // spec section 11: "Never allow negative coins"
            prefs[Keys.HEARTS] = progress.hearts.coerceIn(0, progress.maxHearts)
            prefs[Keys.MAX_HEARTS] = progress.maxHearts
            prefs[Keys.HIGHEST_UNLOCKED] = progress.highestUnlockedLevel
            prefs[Keys.STARS_PER_LEVEL] = encodeIntMap(progress.starsPerLevel)
            prefs[Keys.BEST_SCORE_PER_LEVEL] = encodeIntMap(progress.bestScorePerLevel)
            prefs[Keys.POWER_UP_INVENTORY] = encodePowerUpMap(progress.powerUpInventory)
            prefs[Keys.MUSIC_ON] = progress.musicOn
            prefs[Keys.SOUND_ON] = progress.soundOn
            prefs[Keys.VIBRATION_ON] = progress.vibrationOn
            prefs[Keys.SELECTED_THEME] = progress.selectedTheme
            prefs[Keys.SELECTED_SKIN] = progress.selectedBubbleSkin
            prefs[Keys.OWNED_THEMES] = encodeStringSet(progress.ownedThemes)
            prefs[Keys.OWNED_SKINS] = encodeStringSet(progress.ownedBubbleSkins)
            prefs[Keys.DAILY_REWARD_DAY] = progress.dailyRewardDay
            progress.dailyRewardLastClaimEpochDay?.let { prefs[Keys.DAILY_REWARD_LAST_CLAIM] = it }
            if (progress.heartRegenStartEpochMillis != null) {
                prefs[Keys.HEART_REGEN_START] = progress.heartRegenStartEpochMillis
            } else {
                prefs.remove(Keys.HEART_REGEN_START) // hearts are full — clear any stale countdown
            }
            prefs[Keys.LANGUAGE] = progress.language
        }
    }

    /** Wipes all saved data back to defaults (spec section 16: "Reset Progress"). */
    suspend fun resetAll() {
        ds.edit { it.clear() }
    }

    private fun encodeIntMap(map: Map<Int, Int>): String =
        map.entries.joinToString(",") { "${it.key}:${it.value}" }

    private fun decodeIntMap(raw: String?): Map<Int, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        return raw.split(",").mapNotNull { entry ->
            val parts = entry.split(":")
            val key = parts.getOrNull(0)?.toIntOrNull()
            val value = parts.getOrNull(1)?.toIntOrNull()
            if (key != null && value != null) key to value else null
        }.toMap()
    }

    private fun encodePowerUpMap(map: Map<PowerUpType, Int>): String =
        map.entries.joinToString(",") { "${it.key.name}:${it.value}" }

    private fun decodePowerUpMap(raw: String?): Map<PowerUpType, Int>? {
        if (raw.isNullOrBlank()) return null
        val decoded = raw.split(",").mapNotNull { entry ->
            val parts = entry.split(":")
            val type = parts.getOrNull(0)?.let { name -> runCatching { PowerUpType.valueOf(name) }.getOrNull() }
            val value = parts.getOrNull(1)?.toIntOrNull()
            if (type != null && value != null) type to value else null
        }.toMap()
        // Make sure every PowerUpType has an entry even if it was added after this save was written.
        return PowerUpType.entries.associateWith { decoded[it] ?: 0 }
    }

    private fun encodeStringSet(set: Set<String>): String = set.joinToString(",")

    private fun decodeStringSet(raw: String?): Set<String>? {
        if (raw.isNullOrBlank()) return null
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }
}
