package com.bubbleblastbangla.game

import com.bubbleblastbangla.data.models.LevelConfig
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.data.models.TargetType
import com.bubbleblastbangla.game.board.BubbleGrid
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath
import com.bubbleblastbangla.game.matching.FallDetector
import com.bubbleblastbangla.game.matching.MatchFinder
import com.bubbleblastbangla.game.model.BubbleColor
import com.bubbleblastbangla.game.powerups.PowerUpEffect
import com.bubbleblastbangla.game.shooter.Shooter
import com.bubbleblastbangla.game.shooter.TrajectoryCalculator
import com.bubbleblastbangla.game.util.PointF

enum class SpecialTier { NONE, SPECIAL_4, SPECIAL_5_PLUS }

/** Everything that happened as a result of one shot — the UI layer animates/renders from this. */
data class FireResult(
    val path: List<PointF>,
    val landingCell: CellCoord,
    val landingColor: BubbleColor,
    val matchedCells: Set<CellCoord>,
    val specialTier: SpecialTier,
    val fallenCells: Set<CellCoord>,
    val scoreDelta: Int,
    val shotsRemaining: Int,
    val isLevelCleared: Boolean,
    val isOutOfShots: Boolean,
    val starsEarned: Int
)

/** Result of using a power-up mid-level (spec section 6). Does not consume a shot. */
data class PowerUpResult(
    val destroyedCells: Set<CellCoord>,
    val fallenCells: Set<CellCoord>,
    val scoreDelta: Int,
    val isLevelCleared: Boolean,
    val starsEarned: Int
)

/**
 * Orchestrates one level playthrough on top of the pure board/matching/
 * shooter/power-up pieces, driven by a real [LevelConfig] (spec section 7).
 * No Compose dependency — see the Phase 1 architecture note.
 */
class GameSession(
    val levelConfig: LevelConfig,
    val grid: BubbleGrid,
    val gridMath: GridMath,
    private val boardWidthPx: Float
) {
    var score: Int = 0
        private set
    var shotsRemaining: Int = levelConfig.shotLimit
        private set

    val shooter: Shooter = Shooter(grid.distinctColors())

    private var finished = false

    fun fire(startPosition: PointF, angleFromVerticalRadians: Float): FireResult {
        check(!finished) { "GameSession already finished — start a new session for the next level." }

        val trajectory = TrajectoryCalculator.simulate(
            start = startPosition,
            angleFromVerticalRadians = angleFromVerticalRadians,
            boardWidthPx = boardWidthPx,
            grid = grid,
            gridMath = gridMath
        )

        val firedColor = shooter.current
        grid.set(trajectory.landingCell, firedColor)

        val (matched, special, fallen, scoreDelta) = resolveMatchAt(trajectory.landingCell)

        score += scoreDelta
        shotsRemaining = (shotsRemaining - 1).coerceAtLeast(0)
        shooter.advance(grid.distinctColors())

        val cleared = isTargetMet()
        val outOfShots = !cleared && shotsRemaining <= 0
        if (cleared || outOfShots) finished = true

        return FireResult(
            path = trajectory.path,
            landingCell = trajectory.landingCell,
            landingColor = firedColor,
            matchedCells = matched,
            specialTier = special,
            fallenCells = fallen,
            scoreDelta = scoreDelta,
            shotsRemaining = shotsRemaining,
            isLevelCleared = cleared,
            isOutOfShots = outOfShots,
            starsEarned = if (cleared) starsFor(score) else 0
        )
    }

    /** Applies a power-up at [target] (spec section 6). Does not consume a shot or change the shooter queue. */
    fun usePowerUp(type: PowerUpType, target: CellCoord): PowerUpResult {
        check(!finished) { "GameSession already finished." }

        val impact = PowerUpEffect.apply(type, grid, gridMath, target)
        impact.destroyedCells.forEach { grid.remove(it) }
        var scoreDelta = impact.destroyedCells.size * 15

        val fallen = FallDetector.findFloatingCells(grid, gridMath)
        fallen.forEach { grid.remove(it) }
        scoreDelta += fallen.size * 20

        score += scoreDelta
        val cleared = isTargetMet()
        if (cleared) finished = true

        return PowerUpResult(
            destroyedCells = impact.destroyedCells,
            fallenCells = fallen,
            scoreDelta = scoreDelta,
            isLevelCleared = cleared,
            starsEarned = if (cleared) starsFor(score) else 0
        )
    }

    private data class MatchOutcome(
        val matched: Set<CellCoord>,
        val special: SpecialTier,
        val fallen: Set<CellCoord>,
        val scoreDelta: Int
    )

    private fun resolveMatchAt(landingCell: CellCoord): MatchOutcome {
        val cluster = MatchFinder.clusterOf(grid, gridMath, landingCell)
        if (cluster.size < 3) return MatchOutcome(emptySet(), SpecialTier.NONE, emptySet(), 0)

        val special = when {
            cluster.size >= 5 -> SpecialTier.SPECIAL_5_PLUS
            cluster.size == 4 -> SpecialTier.SPECIAL_4
            else -> SpecialTier.NONE
        }
        cluster.forEach { grid.remove(it) }
        var scoreDelta = cluster.size * 10 // spec section 5: matched bubbles score

        val fallen = FallDetector.findFloatingCells(grid, gridMath)
        fallen.forEach { grid.remove(it) }
        scoreDelta += fallen.size * 20 // spec section 5: falling bubbles give bonus points

        return MatchOutcome(cluster, special, fallen, scoreDelta)
    }

    private fun isTargetMet(): Boolean = when (levelConfig.targetType) {
        TargetType.CLEAR_ALL -> grid.isEmpty()
        TargetType.SCORE_TARGET -> score >= levelConfig.targetValue
        TargetType.COLOR_TARGET -> grid.isEmpty() // not yet differentiated from CLEAR_ALL — see TargetType doc
    }

    private fun starsFor(finalScore: Int): Int = when {
        finalScore >= levelConfig.starThresholds.threeStarScore -> 3
        finalScore >= levelConfig.starThresholds.twoStarScore -> 2
        else -> 1
    }

    companion object {
        /** Builds a session from a real [LevelConfig] (spec section 7), replacing Phase 3's hardcoded default board. */
        fun create(levelConfig: LevelConfig, boardWidthPx: Float, cols: Int = GridMath.STANDARD_COLS, rows: Int = 12): GameSession {
            val radius = boardWidthPx / (cols * 2f)
            val gridMath = GridMath(radius, cols)
            val grid = BubbleGrid(rows, cols)
            val colors = levelConfig.palette

            val layout = mutableMapOf<CellCoord, BubbleColor>()
            for (row in 0 until levelConfig.filledRows) {
                val colsInRow = if (gridMath.isOddRow(row)) cols - 1 else cols
                for (col in 0 until colsInRow) {
                    val cell = CellCoord(row, col)
                    if (cell.row to cell.col in levelConfig.obstacleCells) continue
                    layout[cell] = colors.random()
                }
            }
            grid.loadLayout(layout)

            return GameSession(levelConfig, grid, gridMath, boardWidthPx)
        }
    }
}
