package com.bubbleblastbangla.ui.gameplay

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bubbleblastbangla.data.level.LevelRepository
import com.bubbleblastbangla.data.models.PowerUpType
import com.bubbleblastbangla.data.repository.ProgressRepository
import com.bubbleblastbangla.game.GameSession
import com.bubbleblastbangla.game.board.CellCoord
import com.bubbleblastbangla.game.board.GridMath
import com.bubbleblastbangla.game.model.BubbleColor
import com.bubbleblastbangla.game.shooter.TrajectoryCalculator
import com.bubbleblastbangla.game.util.PointF
import com.bubbleblastbangla.ui.theme.BubbleOrange
import com.bubbleblastbangla.ui.theme.BubblePurpleGame
import com.bubbleblastbangla.ui.theme.BubbleRed
import com.bubbleblastbangla.ui.theme.BubbleYellowGame
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.max

enum class LevelResult { CLEARED, OUT_OF_SHOTS }

/**
 * Owns one [GameSession] and exposes Compose-observable state to
 * [GameplayScreen]. This is the boundary between the Compose-free game/
 * engine and the UI: it converts PointF <-> Offset, drives shot animation,
 * and — new in Phase 4 — reports level results and power-up usage back to
 * the shared [ProgressRepository] (coins, hearts, stars, inventory).
 */
class GameplayViewModel : ViewModel() {

    private var session: GameSession? = null
    private var progressRepository: ProgressRepository? = null
    private var levelNumber: Int = 1
    private var boardWidthPx = 0f
    private var boardHeightPx = 0f

    var gridState by mutableStateOf<Map<CellCoord, BubbleColor>>(emptyMap())
        private set
    var shooterColor by mutableStateOf(BubbleColor.RED)
        private set
    var nextColor by mutableStateOf(BubbleColor.RED)
        private set
    var score by mutableIntStateOf(0)
        private set
    var shotsRemaining by mutableIntStateOf(0)
        private set
    var trajectoryPreview by mutableStateOf<List<Offset>>(emptyList())
        private set
    var isAnimatingShot by mutableStateOf(false)
        private set
    var flyingBubble by mutableStateOf<Offset?>(null)
        private set
    var flyingBubbleColor by mutableStateOf(BubbleColor.RED)
        private set
    var levelResult by mutableStateOf<LevelResult?>(null)
        private set
    var starsEarned by mutableIntStateOf(0)
        private set
    var coinsEarned by mutableIntStateOf(0)
        private set
    var selectedPowerUp by mutableStateOf<PowerUpType?>(null)
        private set
    var purchaseMessage by mutableStateOf<String?>(null)
        private set

    /** Swapped for a real sound/animation-triggering implementation in Phase 6; no-op today. */
    var audioHooks: GameplayAudioHooks = GameplayAudioHooks.NoOp

    var boardMath: GridMath? = null
        private set

    var skinId by mutableStateOf("classic")
        private set

    /** Bounded, plain (non-Compose-state) particle store — GameplayScreen ticks and draws it each frame (spec section 5 / Phase 6 item 5). */
    val particleSystem = ParticleSystem()

    val shooterAnchor: Offset
        get() = Offset(boardWidthPx / 2f, boardHeightPx - (boardMath?.radius ?: 0f) - 24f)

    /** Called once from the screen when both the level number and the measured board size are known. */
    fun initSession(levelNumber: Int, progressRepository: ProgressRepository, widthPx: Float, heightPx: Float) {
        if (session != null) return // already initialized for this level
        this.levelNumber = levelNumber
        this.progressRepository = progressRepository
        boardWidthPx = widthPx
        boardHeightPx = heightPx
        // Spec section 12 / Phase 5.1 item 1: the skin the player selected in
        // the Shop is loaded once here and used for the whole session — matches
        // "changing the selected skin in Shop should affect FUTURE gameplay",
        // not the level already in progress.
        skinId = progressRepository.progress.value.selectedBubbleSkin

        val levelConfig = LevelRepository.configFor(levelNumber)
        val newSession = GameSession.create(levelConfig, widthPx)
        session = newSession
        boardMath = newSession.gridMath
        syncStateFromSession(newSession)
    }

    fun selectPowerUp(type: PowerUpType) {
        if (isAnimatingShot || levelResult != null) return
        selectedPowerUp = if (selectedPowerUp == type) null else type // tap again to deselect
    }

    /**
     * Tapping a power-up button either selects it for use (if the player
     * already owns one) or attempts a quick purchase (if inventory is 0) —
     * spec section 6 / Phase 4 checklist item 4: "Power-ups can be earned
     * or purchased." A full Shop screen with browsing/preview arrives in
     * Phase 5; this is the minimal, real purchase path so the earn-and-use
     * loop is genuinely testable now rather than deferred.
     */
    fun onPowerUpButtonTap(type: PowerUpType) {
        if (isAnimatingShot || levelResult != null) return
        val repo = progressRepository ?: return

        val available = repo.progress.value.powerUpInventory[type] ?: 0
        if (available > 0) {
            selectPowerUp(type)
            return
        }

        val purchased = repo.purchasePowerUp(type)
        if (purchased) audioHooks.onPowerUpPurchased(type)
        purchaseMessage = if (purchased) {
            "${type.displayName} purchased for ${type.coinCost} coins!"
        } else {
            "Not enough coins — need ${type.coinCost} for ${type.displayName}"
        }
    }

    fun clearPurchaseMessage() {
        purchaseMessage = null
    }

    /** Board tapped while a power-up is selected — applies it at the nearest cell. */
    fun onPowerUpTarget(point: Offset) {
        val type = selectedPowerUp ?: return
        val s = session ?: return
        val math = boardMath ?: return
        val repo = progressRepository ?: return
        if (isAnimatingShot || levelResult != null) return

        if (!repo.consumePowerUp(type)) {
            selectedPowerUp = null // nothing left in inventory — nothing to apply
            return
        }
        audioHooks.onPowerUpUsed(type)

        val cell = math.nearestCell(PointF(point.x, point.y), s.grid.rows - 1)
        val result = s.usePowerUp(type, cell)
        selectedPowerUp = null
        syncStateFromSession(s)

        val burstColor = powerUpBurstColor(type)
        result.destroyedCells.forEach { c ->
            val center = math.cellCenter(c)
            particleSystem.spawnPop(center.x, center.y, burstColor, math.radius * 0.94f)
            particleSystem.spawnBurst(center.x, center.y, burstColor)
        }
        result.fallenCells.forEach { c -> val center = math.cellCenter(c); particleSystem.spawnBurst(center.x, center.y, burstColor, count = 4, speed = 120f) }

        if (result.destroyedCells.isNotEmpty()) audioHooks.onBubblesMatched(result.destroyedCells.size)
        if (result.fallenCells.isNotEmpty()) audioHooks.onBubblesFell(result.fallenCells.size)

        if (result.isLevelCleared) {
            starsEarned = result.starsEarned
            coinsEarned = s.levelConfig.coinReward
            repo.recordLevelResult(levelNumber, result.starsEarned, s.score, coinsEarned)
            audioHooks.onLevelCleared()
            levelResult = LevelResult.CLEARED
        }
    }

    /** Drag in progress — updates the aim trajectory preview. Angle is clamped to a sensible shooting cone. */
    fun onAim(pointer: Offset) {
        if (selectedPowerUp != null) return
        val math = boardMath ?: return
        val s = session ?: return

        val dx = pointer.x - shooterAnchor.x
        val dy = pointer.y - shooterAnchor.y
        // Angle from straight-up, clamped so the player can't aim sideways/down.
        var angle = atan2(dx, -dy)
        val maxAngle = (80.0 * PI / 180.0).toFloat()
        angle = angle.coerceIn(-maxAngle, maxAngle)

        val preview = TrajectoryCalculator.simulate(
            start = PointF(shooterAnchor.x, shooterAnchor.y),
            angleFromVerticalRadians = angle,
            boardWidthPx = boardWidthPx,
            grid = s.grid,
            gridMath = math
        )
        trajectoryPreview = preview.path.map { Offset(it.x, it.y) }
        lastAimAngle = angle
    }

    private var lastAimAngle = 0f

    /** Finger lifted — commit the shot using the last aimed angle. */
    fun onAimEnd() {
        if (selectedPowerUp != null) return
        val s = session ?: return
        if (isAnimatingShot || levelResult != null) {
            trajectoryPreview = emptyList()
            return
        }
        fire(s, lastAimAngle)
    }

    private fun fire(s: GameSession, angle: Float) {
        isAnimatingShot = true
        flyingBubbleColor = shooterColor
        audioHooks.onShotFired()
        val result = s.fire(PointF(shooterAnchor.x, shooterAnchor.y), angle)
        trajectoryPreview = emptyList()

        viewModelScope.launch {
            val points = result.path.map { Offset(it.x, it.y) }
            if (points.size >= 2) {
                val progress = Animatable(0f)
                val segmentLengths = FloatArray(points.size - 1) { i ->
                    (points[i + 1] - points[i]).getDistance()
                }
                val totalLength = max(segmentLengths.sum(), 1f)
                val durationMs = (totalLength / 1400f * 1000f).toInt().coerceIn(120, 900)

                progress.animateTo(1f, animationSpec = androidx.compose.animation.core.tween(durationMs)) {
                    flyingBubble = pointAlongPath(points, segmentLengths, totalLength, value)
                }
            }

            flyingBubble = null
            isAnimatingShot = false
            syncStateFromSession(s)

            boardMath?.let { math ->
                result.matchedCells.forEach { c ->
                    val center = math.cellCenter(c)
                    particleSystem.spawnPop(center.x, center.y, result.landingColor.toComposeColor(), math.radius * 0.94f)
                    particleSystem.spawnBurst(center.x, center.y, result.landingColor.toComposeColor())
                }
                result.fallenCells.forEach { c -> val center = math.cellCenter(c); particleSystem.spawnBurst(center.x, center.y, result.landingColor.toComposeColor(), count = 4, speed = 120f) }
            }

            if (result.matchedCells.isNotEmpty()) audioHooks.onBubblesMatched(result.matchedCells.size)
            if (result.fallenCells.isNotEmpty()) audioHooks.onBubblesFell(result.fallenCells.size)

            val repo = progressRepository
            when {
                result.isLevelCleared -> {
                    starsEarned = result.starsEarned
                    coinsEarned = s.levelConfig.coinReward
                    repo?.recordLevelResult(levelNumber, result.starsEarned, s.score, coinsEarned)
                    audioHooks.onLevelCleared()
                    levelResult = LevelResult.CLEARED
                }
                result.isOutOfShots -> {
                    repo?.loseHeart() // spec section 14: "Losing a level: -1 heart"
                    audioHooks.onLevelFailed()
                    levelResult = LevelResult.OUT_OF_SHOTS
                }
            }
        }
    }

    private fun pointAlongPath(points: List<Offset>, segmentLengths: FloatArray, totalLength: Float, t: Float): Offset {
        var target = t * totalLength
        for (i in segmentLengths.indices) {
            val len = segmentLengths[i]
            if (target <= len || i == segmentLengths.lastIndex) {
                val segT = if (len == 0f) 0f else (target / len).coerceIn(0f, 1f)
                return Offset(
                    points[i].x + (points[i + 1].x - points[i].x) * segT,
                    points[i].y + (points[i + 1].y - points[i].y) * segT
                )
            }
            target -= len
        }
        return points.last()
    }

    private fun syncStateFromSession(s: GameSession) {
        gridState = s.grid.snapshot()
        shooterColor = s.shooter.current
        nextColor = s.shooter.next
        score = s.score
        shotsRemaining = s.shotsRemaining
    }

    /** One distinct particle color per power-up (spec section 4: "Each power-up needs a distinct visual effect"). */
    private fun powerUpBurstColor(type: PowerUpType): Color = when (type) {
        PowerUpType.BOMB -> BubbleOrange
        PowerUpType.LIGHTNING -> BubbleYellowGame
        PowerUpType.RAINBOW -> BubblePurpleGame
        PowerUpType.FIREBALL -> BubbleRed
    }
}
