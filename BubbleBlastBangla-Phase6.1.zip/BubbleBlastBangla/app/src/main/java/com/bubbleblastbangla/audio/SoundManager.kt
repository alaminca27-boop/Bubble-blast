package com.bubbleblastbangla.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log

/**
 * Plays short sound effects via [SoundPool] (spec section 18). Every load
 * and play call is wrapped so a missing/corrupt asset can never crash the
 * app — see the class doc on [SoundEvent] for why no actual audio ships
 * with this project.
 *
 * Loading is lazy and cached: the first time an event is requested, its
 * resource is resolved by name and loaded; after that, playback is
 * essentially free. [release] must be called when the app is done with
 * audio (see [com.bubbleblastbangla.app.BubbleBlastApplication]) to avoid
 * leaking the underlying native SoundPool.
 */
class SoundManager(private val context: Context) {

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val loadedSoundIds = HashMap<SoundEvent, Int?>() // null = resolved as "no asset available", don't retry every call

    fun play(event: SoundEvent) {
        try {
            val soundId = loadedSoundIds.getOrPut(event) { loadSound(event) } ?: return
            soundPool.play(soundId, 1f, 1f, 0, 0, 1f)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to play ${event.name}: ${e.message}")
        }
    }

    private fun loadSound(event: SoundEvent): Int? {
        return try {
            val resId = context.resources.getIdentifier(event.rawResName, "raw", context.packageName)
            if (resId == 0) return null // no asset shipped for this event yet — expected until Phase 6 assets are added
            soundPool.load(context, resId, 1)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load ${event.name}: ${e.message}")
            null
        }
    }

    fun release() {
        try {
            soundPool.release()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to release SoundPool: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "SoundManager"
    }
}
