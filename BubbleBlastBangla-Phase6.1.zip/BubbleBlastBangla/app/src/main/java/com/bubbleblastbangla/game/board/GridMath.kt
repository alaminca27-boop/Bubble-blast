package com.bubbleblastbangla.game.board

import com.bubbleblastbangla.game.util.PointF
import kotlin.math.roundToInt

/**
 * Geometry for the "offset row" bubble grid: even rows sit flush left, odd
 * rows are shifted right by half a bubble diameter — the standard brick-like
 * layout used by Puzzle Bobble-style games (spec section 8: "How the bubble
 * physics/matching system will work").
 *
 * All positions are in pixels relative to the board's top-left corner. The
 * caller (BubbleGrid / TrajectoryCalculator) supplies [radius] once, derived
 * from the actual board width measured on screen.
 */
class GridMath(val radius: Float, val cols: Int) {

    val diameter = radius * 2f
    val rowHeight = diameter * 0.8660254f // sqrt(3)/2 — vertical spacing for tightly packed circles

    fun isOddRow(row: Int) = row % 2 == 1

    /** Center position (in px) of the bubble at [cell]. */
    fun cellCenter(cell: CellCoord): PointF {
        val xOffset = if (isOddRow(cell.row)) radius else 0f
        val x = cell.col * diameter + radius + xOffset
        val y = cell.row * rowHeight + radius
        return PointF(x, y)
    }

    /** Neighbor cells of [cell] in the offset grid (up to 6). */
    fun neighborsOf(cell: CellCoord): List<CellCoord> {
        val row = cell.row
        val col = cell.col
        return if (isOddRow(row)) {
            listOf(
                CellCoord(row, col - 1), CellCoord(row, col + 1),
                CellCoord(row - 1, col), CellCoord(row - 1, col + 1),
                CellCoord(row + 1, col), CellCoord(row + 1, col + 1)
            )
        } else {
            listOf(
                CellCoord(row, col - 1), CellCoord(row, col + 1),
                CellCoord(row - 1, col - 1), CellCoord(row - 1, col),
                CellCoord(row + 1, col - 1), CellCoord(row + 1, col)
            )
        }
    }

    /** Nearest valid cell to an arbitrary pixel point — used to snap a landing bubble to the grid. */
    fun nearestCell(point: PointF, maxRow: Int): CellCoord {
        val approxRow = (point.y / rowHeight).roundToInt().coerceIn(0, maxRow)
        var best: CellCoord? = null
        var bestDist = Float.MAX_VALUE
        // Check the approximate row and its neighbors — the true nearest cell
        // is always within one row of the naive y-based estimate.
        for (row in (approxRow - 1)..(approxRow + 1)) {
            if (row < 0 || row > maxRow) continue
            val xOffset = if (isOddRow(row)) radius else 0f
            val approxCol = ((point.x - xOffset - radius) / diameter).roundToInt()
            for (col in (approxCol - 1)..(approxCol + 1)) {
                if (col < 0 || col >= cols) continue
                val candidate = CellCoord(row, col)
                val dist = cellCenter(candidate).distanceTo(point)
                if (dist < bestDist) {
                    bestDist = dist
                    best = candidate
                }
            }
        }
        return best ?: CellCoord(approxRow, 0)
    }

    companion object {
        /** Standard number of columns in an even row — used to derive [radius] from measured board width. */
        const val STANDARD_COLS = 8
    }
}
