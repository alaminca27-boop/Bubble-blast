package com.bubbleblastbangla.ui.levelcomplete

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bubbleblastbangla.state.rememberProgressRepository
import com.bubbleblastbangla.ui.components.RoundedGameButton
import com.bubbleblastbangla.ui.theme.BackgroundForestBottom
import com.bubbleblastbangla.ui.theme.BackgroundForestTop
import com.bubbleblastbangla.ui.theme.BubbleBlue
import com.bubbleblastbangla.ui.theme.BubbleGreen
import com.bubbleblastbangla.ui.theme.BubbleYellow
import com.bubbleblastbangla.ui.theme.CoinGold
import com.bubbleblastbangla.ui.theme.LockedGray
import com.bubbleblastbangla.ui.theme.SurfaceCard
import com.bubbleblastbangla.ui.theme.TextPrimary

/**
 * Level Complete screen (spec section 9). The reward was already granted
 * exactly once by GameplayViewModel before navigating here — this screen
 * only displays it (score/stars/coins arrive as real nav arguments), it
 * never re-grants anything, so retrying/reopening this screen can't
 * duplicate a reward.
 */
@Composable
fun LevelCompleteScreen(
    levelNumber: Int,
    score: Int,
    stars: Int,
    coinsEarned: Int,
    onHome: () -> Unit,
    onRetry: () -> Unit,
    onNextLevel: () -> Unit
) {
    val progressRepository = rememberProgressRepository()
    val progress by progressRepository.progress.collectAsState()
    val bestScore = progress.bestScorePerLevel[levelNumber] ?: score
    val isLastLevel = levelNumber >= com.bubbleblastbangla.data.level.LevelRepository.TOTAL_LEVELS
    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as com.bubbleblastbangla.app.BubbleBlastApplication
    LaunchedEffect(Unit) { app.audio.playMusic(com.bubbleblastbangla.audio.MusicTrack.LEVEL_COMPLETE) }

    var animatedCoins by remember { mutableIntStateOf(0) }
    var starsRevealed by remember { mutableIntStateOf(0) }

    LaunchedEffect(coinsEarned) {
        val anim = Animatable(0f)
        anim.animateTo(coinsEarned.toFloat(), animationSpec = tween(700, easing = LinearOutSlowInEasing)) {
            animatedCoins = value.toInt()
        }
    }
    LaunchedEffect(stars) {
        repeat(stars) { i ->
            kotlinx.coroutines.delay(220)
            starsRevealed = i + 1
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = listOf(BackgroundForestTop, BackgroundForestBottom)))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "LEVEL COMPLETE!",
            style = MaterialTheme.typography.displayLarge,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(12.dp))
        com.bubbleblastbangla.ui.components.PandaMascot(
            size = 90.dp,
            modifier = Modifier.size(90.dp),
            mood = com.bubbleblastbangla.ui.components.PandaMood.HAPPY
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row {
            repeat(3) { i ->
                Text(
                    text = "\u2605",
                    color = if (i < starsRevealed) BubbleYellow else LockedGray,
                    style = MaterialTheme.typography.displayLarge
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StatRow(label = "Score", value = score.toString())
            StatRow(label = "Best Score", value = bestScore.toString())
            StatRow(label = "Coins Earned", value = "+$animatedCoins", valueColor = CoinGold)
        }

        Spacer(modifier = Modifier.height(28.dp))

        if (!isLastLevel) {
            RoundedGameButton(text = "NEXT LEVEL", baseColor = BubbleGreen, onClick = onNextLevel)
            Spacer(modifier = Modifier.height(12.dp))
        }
        RoundedGameButton(text = "RETRY", baseColor = BubbleBlue, onClick = onRetry)
        Spacer(modifier = Modifier.height(12.dp))
        RoundedGameButton(text = "HOME", baseColor = com.bubbleblastbangla.ui.theme.BubblePurple, onClick = onHome)
    }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        Text(text = value, style = MaterialTheme.typography.titleLarge, color = valueColor, fontWeight = FontWeight.Bold)
    }
}
