package com.bubbleblastbangla.ads

/**
 * Modular, optional ads architecture (spec section 23 / Phase 6 item 14).
 * No ad SDK is included — connecting one later means implementing this
 * interface (e.g. `AdMobAdProvider`) and swapping it in at
 * [com.bubbleblastbangla.app.BubbleBlastApplication] construction; nothing
 * else in the app needs to change, since every call site only ever talks
 * to this interface.
 *
 * Every method is a suspend function returning a result rather than firing
 * a callback, and every call site MUST treat "not available" as a normal,
 * silent outcome — ads are never mandatory for gameplay (spec section 23:
 * "Never make an online connection mandatory"), and offline is always one
 * of the expected reasons an ad is unavailable.
 */
interface AdProvider {
    /** True if a rewarded ad is ready to show right now (e.g. loaded and the device is online). */
    suspend fun isRewardedAdAvailable(): Boolean

    /** Shows a rewarded ad if available. Returns true only if the player watched it to completion and should receive the reward. */
    suspend fun showRewardedAd(): Boolean

    suspend fun isInterstitialAdAvailable(): Boolean

    /** Shows an interstitial if available. Never call this during active gameplay (spec section 23). */
    suspend fun showInterstitialAd(): Boolean
}

/**
 * The only implementation shipped today: reports every ad as unavailable.
 * This is what makes Game Over's "Continue" honestly show as disabled
 * instead of faking a working ad flow (spec section 4 / Phase 5 note).
 */
object NoOpAdProvider : AdProvider {
    override suspend fun isRewardedAdAvailable(): Boolean = false
    override suspend fun showRewardedAd(): Boolean = false
    override suspend fun isInterstitialAdAvailable(): Boolean = false
    override suspend fun showInterstitialAd(): Boolean = false
}
