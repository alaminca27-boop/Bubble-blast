package com.bubbleblastbangla.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.unit.Dp
import kotlin.math.sin

/** Lightweight reaction states (spec section 9 / Phase 6 item 9) — no copyrighted assets, purely procedural. */
enum class PandaMood { IDLE, HAPPY, SAD, EXCITED }

/**
 * Simple original vector-drawn panda placeholder — round white head, black ear
 * and eye patches, small nose. Deliberately simple/geometric so it is clearly
 * an original, non-copyrighted design (spec section 21 forbids using
 * copyrighted characters).
 *
 * Phase 6 adds a subtle idle breathing/bounce animation and three reaction
 * moods ([PandaMood.HAPPY] for level complete, [PandaMood.SAD] for game
 * over, [PandaMood.EXCITED] for daily reward) — all procedural (bounce
 * speed/amplitude and eye size only), so no new assets are needed and the
 * mascot stays trivially replaceable with a real illustration later.
 */
@Composable
fun PandaMascot(size: Dp, modifier: Modifier = Modifier, mood: PandaMood = PandaMood.IDLE) {
    val transition = rememberInfiniteTransition(label = "pandaIdle")
    val (periodMs, amplitude) = when (mood) {
        PandaMood.IDLE -> 1800 to 0.03f
        PandaMood.HAPPY -> 500 to 0.08f
        PandaMood.EXCITED -> 350 to 0.09f
        PandaMood.SAD -> 3200 to 0.015f // barely moves — reads as "down"
    }
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(periodMs, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "pandaBouncePhase"
    )

    Canvas(modifier = modifier) {
        val bounce = sin(phase) * (this.size.height * amplitude)
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f + bounce
        val radius = minOf(this.size.width, this.size.height) / 2.2f
        val eyeScale = if (mood == PandaMood.EXCITED || mood == PandaMood.HAPPY) 1.25f else if (mood == PandaMood.SAD) 0.75f else 1f

        // Ears
        drawCircle(Color.Black, radius = radius * 0.32f, center = Offset(cx - radius * 0.75f, cy - radius * 0.75f))
        drawCircle(Color.Black, radius = radius * 0.32f, center = Offset(cx + radius * 0.75f, cy - radius * 0.75f))

        // Head
        drawCircle(Color.White, radius = radius, center = Offset(cx, cy), style = Fill)

        // Eye patches
        val eyeY = if (mood == PandaMood.SAD) cy + radius * 0.02f else cy - radius * 0.05f
        drawCircle(Color.Black, radius = radius * 0.28f, center = Offset(cx - radius * 0.4f, eyeY))
        drawCircle(Color.Black, radius = radius * 0.28f, center = Offset(cx + radius * 0.4f, eyeY))

        // Eyes
        drawCircle(Color.White, radius = radius * 0.09f * eyeScale, center = Offset(cx - radius * 0.38f, eyeY))
        drawCircle(Color.White, radius = radius * 0.09f * eyeScale, center = Offset(cx + radius * 0.38f, eyeY))

        // Nose
        drawCircle(Color.Black, radius = radius * 0.12f, center = Offset(cx, cy + radius * 0.35f))
    }
}
