package com.bubbleblastbangla.haptics

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.bubbleblastbangla.data.repository.ProgressRepository

/**
 * Subtle haptic feedback (spec section 2 / Phase 6 item 2). Every named
 * method maps to one real gameplay/UI moment (button press, shot, match,
 * power-up, level complete, game over, daily reward, purchase, error) with
 * a duration/intensity that fits the moment — short and light for routine
 * taps, a bit longer for level complete/game over.
 *
 * Always checks the existing `vibrationOn` setting and gracefully does
 * nothing on devices with no vibrator or on any API error — never crashes.
 */
class HapticManager(context: Context, private val progressRepository: ProgressRepository) {

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Exception) {
        Log.w(TAG, "No vibrator available: ${e.message}")
        null
    }

    fun buttonPress() = vibrate(15)
    fun bubbleShot() = vibrate(12)
    fun matchSuccess() = vibrate(20)
    fun powerUpActivate() = vibrate(30)
    fun levelComplete() = vibrate(40)
    fun gameOver() = vibrate(35)
    fun dailyRewardClaim() = vibrate(25)
    fun purchaseSuccess() = vibrate(20)
    fun insufficientCoins() = vibrate(15)

    private fun vibrate(durationMs: Long) {
        if (!progressRepository.progress.value.vibrationOn) return
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(durationMs)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration failed: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "HapticManager"
    }
}
