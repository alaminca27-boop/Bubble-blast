This folder intentionally ships empty.

Drop licensed/final audio files here with these exact filenames (any
Android-supported audio format, e.g. .mp3/.ogg/.wav) and they will start
playing automatically — SoundManager/MusicManager look them up by name at
runtime, so no code changes are needed:

Sound effects (see audio/SoundEvent.kt):
  sfx_button_click      sfx_bubble_shot       sfx_bubble_collision
  sfx_bubble_match      sfx_bubble_pop        sfx_bubble_fall
  sfx_powerup_purchase  sfx_powerup_activate  sfx_coin_reward
  sfx_star_earned       sfx_level_complete    sfx_game_over
  sfx_daily_reward      sfx_error

Music tracks (see audio/MusicTrack.kt, i.e. the enum in SoundEvent.kt):
  music_home  music_level_map  music_gameplay  music_level_complete  music_game_over

Do not add copyrighted or placeholder audio without a proper license.
